// #include <math.h>
// #include "F28x_Project.h"
// #include "device.h"
// #include "variables.h"
// #include "cc.h"
// #include "dac.h"
// #include "fault.h"
// #include "inc/hw_can.h"
// #include "CANlibrary.h"

// tCANMsgObject sTXCANMessage;
// tCANMsgObject sRXCANMessage;

// interrupt void CANopen(void)
// {
//    DATA_OBJECT dObj;


//     unsigned char RXdata[8];
//     unsigned char TXdata[8];

//     //CANopen RX
//     unsigned short can_id_receive = SDO_RXID_BASELINE + DEVICE_ID;      //RX ID

//     CAN_PACKET packet_receive;
//     memset(packet_receive.value, 0, sizeof(packet_receive.value));
//     packet_receive.info.attrib = CAN_ATTRIBUTION_READ_1BYTE;
//     dObj.uint16Value[0] = INDEX_FORCECONTROL;
//     packet_receive.info.index[0] = dObj.uint8Value[0];
//     packet_receive.info.index[1] = dObj.uint8Value[1];
//     packet_receive.info.subindex = 0x01;
//     packet_receive.info.data[0] = 4;
//     memcpy(RXdata, packet_receive.value, sizeof(packet_receive.value));
    
//     //CANopen TX
//     unsigned short can_id_transmit = SDO_TXID_BASELINE + DEVICE_ID;     //TX ID

//     CAN_PACKET packet_transmit;
//     memset(packet_transmit.value, 0, sizeof(packet_transmit.value));
//     packet_transmit.info.attrib = CAN_ATTRIBUTION_WRITE_1BYTE;
//     dObj.uint16Value[0] = INDEX_FORCECONTROL;
//     packet_transmit.info.index[0] = dObj.uint8Value[0];
//     packet_transmit.info.index[1] = dObj.uint8Value[1];
//     packet_transmit.info.subindex = 0x01;
//     packet_transmit.info.data[0] = 12;
//     memcpy(TXdata, packet_transmit.value, sizeof(packet_transmit.value));
    
//     TXMsgData[0] = TXdata[4];
//     TXMsgData[1] = TXdata[5];
//     TXMsgData[2] = TXdata[6];
//     TXMsgData[3] = TXdata[7];

//     // RXMsgData[0] = RXdata[4];
//     // RXMsgData[1] = RXdata[5];
//     // RXMsgData[2] = RXdata[6];
//     // RXMsgData[3] = RXdata[7];

        
//     CANMessageSet(CANA_BASE, 1, &sTXCANMessage, MSG_OBJ_TYPE_TX);

//     CANMessageGet(CANA_BASE, can_id_receive - 0x0602, &sRXCANMessage, true);

//     CANIntClear(CANA_BASE, 0);

    
//     CANGlobalIntClear(CANA_BASE, CAN_GLB_INT_CANINT0);
//     PieCtrlRegs.PIEACK.all = PIEACK_GROUP9;
// }
