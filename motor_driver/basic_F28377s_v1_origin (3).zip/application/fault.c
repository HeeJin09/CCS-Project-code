/*
 * fault.c
 *
 *  Created on: 2018. 8. 3.
 *      Author: PowerElabLAPTOP1
 */
#include "F28x_Project.h"
#include "device.h"
#include "variables.h"

void faultManage(void) {
    GD1Fault = (((GpioDataRegs.GPEDAT.all & 0x00fc) >>  2) & 0x3f);
    GD2Fault = (((GpioDataRegs.GPEDAT.all & 0xfc00) >> 10) & 0x3f);
    GD3Fault = (((GpioDataRegs.GPBDAT.all & 0x00fc) >>  2) & 0x3f);
    GD4Fault = (((GpioDataRegs.GPBDAT.all & 0xfc00) >> 10) & 0x3f);

    if(Flags.Fault == 0) {
        if((GD1Fault != 0x3f) || (GD2Fault != 0x3f) || (GD3Fault != 0x3f) || (GD4Fault != 0x3f)) {
            Flags.Fault = 1;
        }
    }
    if(Flags.Fault == 1) {
/*      // Fault disable
        GpioDataRegs.GPCSET.bit.GPIO69 = 1;  // Gate Set #1 Disable
        GpioDataRegs.GPCSET.bit.GPIO70 = 1;  // Gate Set #2 Disable
        GpioDataRegs.GPCSET.bit.GPIO74 = 1;  // Gate Set #3 Disable
        GpioDataRegs.GPCSET.bit.GPIO75 = 1;  // Gate Set #4 Disable

        GD1enable = 0;
        GD2enable = 0;
        GD3enable = 0;
        GD4enable = 0;
*/
        // GpioDataRegs.GPBCLEAR.bit.GPIO48 = 1;       // LED0(Red) Turn on.

    }

}
