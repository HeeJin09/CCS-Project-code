/*
 * fault.h
 *
 *  Created on: 2018. 8. 3.
 *      Author: PowerElabLAPTOP1
 */

#ifndef APPLICATION_FAULT_H_
#define APPLICATION_FAULT_H_

void faultManage(void);



#endif /* APPLICATION_FAULT_H_ */
