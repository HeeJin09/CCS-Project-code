/*
 * cc.c
 *
 *  Created on: 2018. 3. 25.
 *      Author: eunso
 */
#include <math.h>
#include "F28x_Project.h"
#include "device.h"
#include "variables.h"
#include "cc.h"
#include "dac.h"
#include "fault.h"
//#include "Trajectory.h"
//#include "BenchSparseUtil.h"

Uint16 cc_cnt = 0;

Uint16 resultsIndex = 0;
Uint16 sensorSample = 0;
int16 sensorTemp = 0;



Uint16 cc_timer[12];
Uint16 cc_dir = 0;

interrupt void cc_isr(void)
{
    // <-- Timer0 initiation
    ccTimeInit = CPUTimer_getTimerCount(CPUTIMER0_BASE);
    CPUTimer_startTimer(CPUTIMER0_BASE);
    // Timer0 initiation -->

    faultManage();

    daOut();  // daOut() takes about 10[us].
    //UpdateDa();

//    Trajectory::SetPolynomial5th();
//    Trajectory::Polynomial5th();

    AdcaResults[0] = AdcaResultRegs.ADCRESULT0;     // ADC01
    AdcaResults[1] = AdcaResultRegs.ADCRESULT1;     // ADC02
    AdcaResults[2] = AdcaResultRegs.ADCRESULT2;     // ADC03
    AdcaResults[3] = AdcaResultRegs.ADCRESULT3;     // ADC04
    AdcaResults[4] = AdcaResultRegs.ADCRESULT4;     // ADC04
    AdcaResults[5] = AdcaResultRegs.ADCRESULT5;     // ADC05
    sensorSample   = AdcaResultRegs.ADCRESULT6;     // ADC06

    AdcbResults[0] = AdcbResultRegs.ADCRESULT0;     // ADC13
    AdcbResults[1] = AdcbResultRegs.ADCRESULT1;     // ADC14
    AdcbResults[2] = AdcbResultRegs.ADCRESULT2;     // ADC15
    AdcbResults[3] = AdcbResultRegs.ADCRESULT3;     // ADC16
    AdcbResults[4] = AdcbResultRegs.ADCRESULT4;     // ADC17
    AdcbResults[5] = AdcbResultRegs.ADCRESULT5;     // ADC18

    AdccResults[0] = AdccResultRegs.ADCRESULT0;     // ADC07
    AdccResults[1] = AdccResultRegs.ADCRESULT1;     // ADC08
    AdccResults[2] = AdccResultRegs.ADCRESULT2;     // ADC09
    AdccResults[3] = AdccResultRegs.ADCRESULT3;     // ADC10
    AdccResults[4] = AdccResultRegs.ADCRESULT4;     // ADC11
    AdccResults[5] = AdccResultRegs.ADCRESULT5;     // ADC12

    AdcdResults[0] = AdcdResultRegs.ADCRESULT0;     // ADC19
    AdcdResults[1] = AdcdResultRegs.ADCRESULT1;     // ADC20
    AdcdResults[2] = AdcdResultRegs.ADCRESULT2;     // ADC21
    AdcdResults[3] = AdcdResultRegs.ADCRESULT3;     // ADC22
    AdcdResults[4] = AdcdResultRegs.ADCRESULT4;     // ADC23
    AdcdResults[5] = AdcdResultRegs.ADCRESULT5;     // VDDA_5V -> 2.5V
    sensorTemp = GetTemperatureC((int16)sensorSample);

  ////////////////////////////////////////////////////////
    //hand robot inverter
    AdcaValues[5] = (double)AdcaResults[5] / 4096 * 3.3;
    I_Inv1_1 = AdcaValues[5] * 5.*1100./10000; //I = V * 5500/10k

    AdcaValues[4] = (double)AdcaResults[4] / 4096 * 3.3;
    I_Inv1_2 = AdcaValues[4] * 5.*1100./10000; //I = V * 5500/10k

    if(V_Ref_Sat >= 0)
    {
        I_FB = I_Inv1_1;
    }
    else
    {
        I_FB = -1. * (I_Inv1_2);
    }

    if(I_FB > I_max || I_FB < -1. * I_max)
    {
        Flag_Inv1 = 0;
    }

    AdcaValues[3] = (double)AdcaResults[3] / 4096 * 3.3;
    I_Inv2_1 = AdcaValues[3] * 5.*1100./10000; //I = V * 5*1100/10k

    AdcaValues[2] = (double)AdcaResults[2] / 4096 * 3.3;
    I_Inv2_2 = AdcaValues[2] * 5.*1100./10000; //I = V * 5*1100/10k

    if(V_Ref2_Sat >= 0)
    {
        I_FB2 = I_Inv2_1;
    }
    else
    {
        I_FB2 = -1. * (I_Inv2_2);
    }

    if(I_FB2 > I_max || I_FB2 < -1. * I_max)
    {
        Flag_Inv2 = 0;
    }

    AdcaValues[1] = (double)AdcaResults[1] / 4096 * 3.3;
    I_Inv3_1 = AdcaValues[1] * 5.*1100./10000; //I = V * 5*1100/10k

    AdcaValues[0] = (double)AdcaResults[0] / 4096 * 3.3;
    I_Inv3_2 = AdcaValues[0] * 5.*1100./10000; //I = V * 5*1100/10k

    if(V_Ref3_Sat >= 0)
    {
        I_FB3 = I_Inv3_1;
    }
    else
    {
        I_FB3 = -1. * (I_Inv3_2);
    }

    if(I_FB3 > I_max || I_FB3 < -1. * I_max)
    {
        Flag_Inv3 = 0;
    }

    // speed
    ENC_Counter = EQep1Regs.QPOSCNT;

    INV1.PolePair = 1.;
    INV1.Thetarm = BOUND_PI(TWOPI / 1024.*(double)ENC_Counter);
	INV1.Thetae = BOUND_PI(INV1.Thetarm*INV1.PolePair+INV1.Thetae_init);

    if(RXMsgData[1] == 0x61 && RXMsgData[2] == 0x60)
    {
        Flag_Inv1 = RXMsgData[4];
        Flag_Inv2 = RXMsgData[5];
        Flag_Inv3 = RXMsgData[6];
    }
    if(Flag_Inv1 == 0){
        Te_Ref_integ = 0.;
        V_Ref_integ = 0.;
        Err_Theta_pc_dot = 0.;
    }

    ENC_Counter2 = EQep2Regs.QPOSCNT;

    INV2.PolePair = 1.;
    INV2.Thetarm = BOUND_PI(TWOPI / 1024.*(double)ENC_Counter2);
	INV2.Thetae = BOUND_PI(INV2.Thetarm*INV2.PolePair+INV2.Thetae_init);
    
    if(Flag_Inv2 == 0){
        Te_Ref2_integ = 0.;
        V_Ref2_integ = 0.;
    }

    ENC_Counter3 = EQep3Regs.QPOSCNT;

    INV3.PolePair = 1.;
    INV3.Thetarm = BOUND_PI(TWOPI / 1024.*(double)ENC_Counter3);
	INV3.Thetae = BOUND_PI(INV3.Thetarm*INV3.PolePair+INV3.Thetae_init);

    if(Flag_Inv3 == 0){
        Te_Ref3_integ = 0.;
        V_Ref3_integ = 0.;
    }

    //state filter   
    Kp_sf = 2. * zeta * Wsf;
    Ki_sf = Wsf * Wsf;

    //INV1
    Err_Theta = BOUND_PI(INV1.Thetae - Theta_hat);
    
    W_hat_integ += Ki_sf * Err_Theta * Tsamp;

    W_hat = W_hat_integ +  Kp_sf * Err_Theta;

    Theta_hat_pre += W_hat * Tsamp;
    Theta_hat = BOUND_PI(Theta_hat_pre);
    Theta_FB = Theta_hat_pre/GearRatio;
    Wrpm = 60./TWOPI * W_hat;
    RPM_filter = Wrpm / GearRatio;

    //INV2
    Err_Theta2 = BOUND_PI(INV2.Thetae - Theta_hat2);
    
    W_hat2_integ += Ki_sf * Err_Theta2 * Tsamp;

    W_hat2 = W_hat2_integ +  Kp_sf * Err_Theta2;

    Theta_hat2_pre += W_hat2 * Tsamp;
    Theta_hat2 = BOUND_PI(Theta_hat2_pre);
    Theta_FB2 = Theta_hat2_pre/GearRatio;
    Wrpm2 = 60./TWOPI * W_hat2; 
    RPM_filter2 = Wrpm2 / GearRatio;

    //INV3
    Err_Theta3 = BOUND_PI(INV3.Thetae - Theta_hat3);
    
    W_hat3_integ += Ki_sf * Err_Theta3 * Tsamp;

    W_hat3 = W_hat3_integ +  Kp_sf * Err_Theta3;

    Theta_hat3_pre += W_hat3 * Tsamp;
    Theta_hat3 = BOUND_PI(Theta_hat3_pre);
    Theta_FB3 = Theta_hat3_pre/GearRatio;
    Wrpm3 = 60./TWOPI * W_hat3; 
    RPM_filter3 = Wrpm3 / GearRatio;
          

    //position control
    if(RXMsgData[1] == 0x93 && RXMsgData[2] == 0x60)
    {
        Flag_Inv1 =1;
        Flag_Inv2 =1;
        Flag_Inv3 =1;
        Wrmrated = 950;
        Irated = 0.4;
        if( RXMsgData[5] == 0xff && RXMsgData[4] == 0xff)    //Posture 1
        {

            Flag_Inv1 =0;
            Flag_Inv2 =0;
            Flag_Inv3 =0;
            Angle = 0;
            Angle2 = 0;
            Angle3 = 0;
            Theta_hat_pre=0;
            Theta_hat2_pre=0;
            Theta_hat3_pre=0;
        }


        if(RXMsgData[5] == 1 && RXMsgData[4] == 0)    //Posture 1
        {
            Angle = 0;
            Angle2 = 0;
            Angle3 = 0;
        }

        if(RXMsgData[5] == 2 && RXMsgData[4] == 0)    //Posture 2
        {
            Angle = 100;
            Angle2 = 100;
            Angle3 = 100;
        }

        if(RXMsgData[5] == 3 && RXMsgData[4] == 0)    //Posture 3
        {
            Angle = 3000;
            Angle2 = 3000;
            Angle3 = 3000;
        }
        if(RXMsgData[5] == 4 && RXMsgData[4] == 0)    //Posture 3
        {
            Wrmrated = 500;
            Angle = -3000;
            Angle2 = -3000;
            Angle3 = -3000;
        }
        if(RXMsgData[4] == 1)    //Desired
        {
            //Motor 1
            if(RXMsgData[5] == 0){
                // CCW
                if(RXMsgData[6] == 0){
                    Angle = (double)RXMsgData[7]*15;
                }
                // CW
                else if(RXMsgData[6] == 0x1){
                    Angle = -1*(double)RXMsgData[7]*15;
                }
            }
            //Motor 2
            else if(RXMsgData[5] == 0x1){
                // CCW
                if(RXMsgData[6] == 0){
                    Angle2 = (double)RXMsgData[7]*15;
                }
                // CW
                else if(RXMsgData[6] == 1){
                    Angle2 = -1*(double)RXMsgData[7]*15;
                }
            }
            //Motor 3
            else if(RXMsgData[5] == 0x2){
                // CCW
                if(RXMsgData[6] == 0){
                    Angle3 = (double)RXMsgData[7]*15;
                }
                // CW
                else if(RXMsgData[6] == 1){
                    Angle3 = -1*(double)RXMsgData[7]*15;
                }
            }

        }
        // Angle = RXMsgData[4];
        //Angle2 = RXMsgData[5];
        //Angle3 = RXMsgData[6];
    }
    if(test_mc < 10000){
        test_mc += 10;
    }
        //INV1
    Theta_Ref = Angle * TWOPI/360.;
    Theta_Ref = Theta_Ref>=(Theta_FB + 10.) ? (Theta_FB + 10.) : (Theta_Ref <= (Theta_FB - 10.) ? (Theta_FB - 10.) : Theta_Ref);
    Err_Theta_pc = Theta_Ref - Theta_FB;

    Kp_pc = GearRatio*Wc_sc/9.;
    Wrm_Ref = Kp_pc * Err_Theta_pc;



//    if((Flag_pd == 1) && (Cnt_pd >= 20)) {
//        Err_Theta_pc_pd_pre = Err_Theta_pc_pd;
//        Err_Theta_pc_pd = Err_Theta_pc;
//        Err_Theta_pc_dot = (2*Tau- ((double)Cnt_pd*Tsamp)) / (2*Tau + ((double)Cnt_pd*Tsamp)) * Err_Theta_pc_dot + 2 / (2*Tau + ((double)Cnt_pd*Tsamp)) * (Err_Theta_pc_pd - Err_Theta_pc_pd_pre);
//        I_Ref_pd = Kp_pc * Err_Theta_pc + Kd_pc * Err_Theta_pc_dot ;
//        Cnt_pd = 0;
//    }


    if(RXMsgData[1] == 0x81 && RXMsgData[2] == 0x60)
    {
        Wrm_Ref = RXMsgData[4];
    }
    Wrm_Ref = Wrm_Ref>= (Wrm + Wrmrated*0.1) ? (Wrm + Wrmrated*0.1) : ((Wrm_Ref <= (Wrm - Wrmrated*0.1)) ? (Wrm - Wrmrated*0.1) : Wrm_Ref); //Wrm limit
    Wrm_Ref = Wrm_Ref>=Wrmrated ? Wrmrated : (Wrm_Ref <= -Wrmrated ? -Wrmrated : Wrm_Ref); //Wrm limit

        //INV2
    Theta_Ref2 = Angle2 * TWOPI/360.;
    Theta_Ref2 = Theta_Ref2>=(Theta_FB2 + 10.) ? (Theta_FB2 + 10.) : (Theta_Ref2 <= (Theta_FB2 - 10.) ? (Theta_FB2 - 10.) : Theta_Ref2);
    Err_Theta_pc2 = Theta_Ref2 - Theta_FB2;

    Wrm_Ref2 = Kp_pc * Err_Theta_pc2;

    if(RXMsgData[1] == 0x81 && RXMsgData[2] == 0x60)
    {
        Wrm_Ref2 = RXMsgData[5];
    }

    Wrm_Ref2 = Wrm_Ref2>= (Wrm2 + Wrmrated*0.1) ? (Wrm2 + Wrmrated*0.1) : ((Wrm_Ref2 <= (Wrm2 - Wrmrated*0.1)) ? (Wrm2 - Wrmrated*0.1) : Wrm_Ref2); //Wrm limit
    Wrm_Ref2 = Wrm_Ref2>=Wrmrated ? Wrmrated : (Wrm_Ref2 <= -Wrmrated ? -Wrmrated : Wrm_Ref2); //Wrm limit

        //INV3
    Theta_Ref3 = Angle3 * TWOPI/360.;
    Theta_Ref3 = Theta_Ref3>=(Theta_FB3 + 10.) ? (Theta_FB3 + 10.) : (Theta_Ref3 <= (Theta_FB3 - 10.) ? (Theta_FB3 - 10.) : Theta_Ref3);

    Err_Theta_pc3 = Theta_Ref3 - Theta_FB3;

    Wrm_Ref3 = Kp_pc * Err_Theta_pc3;

    if(RXMsgData[1] == 0x81 && RXMsgData[2] == 0x60)
    {
        Wrm_Ref3 = RXMsgData[6];
    }

    Wrm_Ref3 = Wrm_Ref3>= (Wrm3 + Wrmrated*0.1) ? (Wrm3 + Wrmrated*0.1) : ((Wrm_Ref3 <= (Wrm3 - Wrmrated*0.1)) ? (Wrm3 - Wrmrated*0.1) : Wrm_Ref3); //Wrm limit
    Wrm_Ref3 = Wrm_Ref3>=Wrmrated ? Wrmrated : (Wrm_Ref3 <= -Wrmrated ? -Wrmrated : Wrm_Ref3); //Wrm limit

    //speed control
    Kp_sc = J * Wc_sc;
    Ki_sc = Kp_sc * Wc_sc /Ki_sc_ratio;
    Ka_sc = 1./Kp_sc*Ka_sc_ratio;
    
    //INV1
    Cnt_pd++;
    if(Cnt_pd >= 10) {
        Err_Wrm = Wrm_Ref - Wrm;
        Te_Ref_integ += Ki_sc * (Err_Wrm - Ka_sc * Kt * (I_Ref - I_Ref_Sat)) * 10.*Tsamp;

        Te_Ref = Kp_sc * Err_Wrm + Te_Ref_integ - Kad_sc * Wrm;    //PI control

        I_Ref = Te_Ref / Kt;
        Cnt_pd = 0;
    }
    

    if(RXMsgData[1] == 0x71 && RXMsgData[2] == 0x60)
    {
        I_Ref = RXMsgData[4];
    }
        
//    if(Flag_pd == 1) {
//        I_Ref = I_Ref_pd;
//    }
        
    I_Ref_Sat = I_Ref>=Irated ? Irated : (I_Ref <= -Irated ? -Irated : I_Ref); //I_Ref limit

    Kp_cc = Ls * Wcc;
    Ki_cc = Rs * Wcc;
    Ka_cc = 1./Kp_cc*Ka_cc_ratio;

    Err_I_Ref = I_Ref_Sat - I_FB;  
    V_Ref_integ += (Err_I_Ref - Ka_cc * (V_Ref - V_Ref_Sat)) * Ki_cc * Tsamp;
    V_Ref = Kp_cc * Err_I_Ref + V_Ref_integ;
    //V_Ref = Rs * Err_I_Ref +0.55*  Kt * Wrm; //Current control

    if(V_Ref > Vrated){
        V_Ref_Sat = Vrated;       //voltage limit
    }
    else if(V_Ref < -1. * Vrated){
        V_Ref_Sat = -1.*Vrated;
    }
    else {
        V_Ref_Sat = V_Ref;
    }

    //INV2
    Cnt_pd2++;
    if(Cnt_pd2 >= 10) {
        Err_Wrm2 = Wrm_Ref2 - Wrm2;
        Te_Ref2_integ += Ki_sc * (Err_Wrm2 - Ka_sc * (I_Ref2 - I_Ref2_Sat)) * 10.*Tsamp;

        Te_Ref2 = Kp_sc * Err_Wrm2 + Te_Ref2_integ;    //PI control

        I_Ref2 = Te_Ref2 / Kt;
       Cnt_pd2 = 0;
   }


    if(RXMsgData[1] == 0x71 && RXMsgData[2] == 0x60)
    {
        I_Ref2 = RXMsgData[5];
    }
        
    I_Ref2_Sat = I_Ref2>=Irated ? Irated : (I_Ref2 <= -Irated ? -Irated : I_Ref2); //I_Ref2 limit

    Err_I_Ref2 = I_Ref2_Sat - I_FB2;  
    V_Ref2_integ += (Err_I_Ref2 - Ka_cc * (V_Ref2 - V_Ref2_Sat)) * Ki_cc * Tsamp;
    V_Ref2 = Kp_cc * Err_I_Ref2 + V_Ref2_integ;
    //V_Ref2 = Rs * Err_I_Ref2 + Kt * Wrm; //Current control

    if(V_Ref2 > Vrated){
        V_Ref2_Sat = Vrated;       //voltage limit
    }
    else if(V_Ref2 < -1. * Vrated){
        V_Ref2_Sat = -1.*Vrated;
    }
    else {
        V_Ref2_Sat = V_Ref2;
    }

    //INV3
    Cnt_pd3++;
    if(Cnt_pd3 >= 10) {
        Err_Wrm3 = Wrm_Ref3 - Wrm3;
        Te_Ref3_integ += Ki_sc * (Err_Wrm3 - Ka_sc * (I_Ref3 - I_Ref3_Sat)) * 10.*Tsamp;

        Te_Ref3 = Kp_sc * Err_Wrm3 + Te_Ref3_integ;    //PI control

        I_Ref3 = Te_Ref3 / Kt;
        Cnt_pd3 = 0;
    }
    

    if(RXMsgData[1] == 0x71 && RXMsgData[2] == 0x60)
    {
        I_Ref3 = RXMsgData[6];
    }
        
    I_Ref3_Sat = I_Ref3>=Irated ? Irated : (I_Ref3 <= -Irated ? -Irated : I_Ref3); //I_Ref3 limit

    Err_I_Ref3 = I_Ref3_Sat - I_FB3;  
    V_Ref3_integ += (Err_I_Ref3 - Ka_cc * (V_Ref3 - V_Ref3_Sat)) * Ki_cc * Tsamp;
    V_Ref3 = Kp_cc * Err_I_Ref3 + V_Ref3_integ;
    //V_Ref3 = Rs * Err_I_Ref3 + 2*Kt * Wrm; //Current control

    if(V_Ref3 > Vrated){
        V_Ref3_Sat = Vrated;       //voltage limit
    }
    else if(V_Ref3 < -1. * Vrated){
        V_Ref3_Sat = -1.*Vrated;
    }
    else {
        V_Ref3_Sat = V_Ref3;
    }

    Vref = V_Ref_Sat;    //Vrm_hat -> Vref
    Wrm = W_hat;

    Vref2 = V_Ref2_Sat;    //Vrm_hat -> Vref
    Wrm2 = W_hat2;

    Vref3 = V_Ref3_Sat;    //Vrm_hat -> Vref
    Wrm3 = W_hat3;

    //INV1
    Vdcinv = 1./Vrated;
    EPCountA = PeriodCountmax * (0.5 + 0.5 * Vref*Vdcinv);
    EPCountB = PeriodCountmax * (0.5 - 0.5 * Vref*Vdcinv);

    EPCountA = EPCountA >= PeriodCountmax ? PeriodCountmax : (EPCountA <= 0 ? 0 : EPCountA);
    EPCountB = EPCountB >= PeriodCountmax ? PeriodCountmax : (EPCountB <= 0 ? 0 : EPCountB);

    EPwmCountA = (Uint16)(EPCountA);
    EPwmCountB = (Uint16)(EPCountB);  

    //INV2
    EPCountA2 = PeriodCountmax * (0.5 + 0.5 * Vref2*Vdcinv);
    EPCountB2 = PeriodCountmax * (0.5 - 0.5 * Vref2*Vdcinv);

    EPCountA2 = EPCountA2 >= PeriodCountmax ? PeriodCountmax : (EPCountA2 <= 0 ? 0 : EPCountA2);
    EPCountB2 = EPCountB2 >= PeriodCountmax ? PeriodCountmax : (EPCountB2 <= 0 ? 0 : EPCountB2);

    EPwmCountA2 = (Uint16)(EPCountA2);
    EPwmCountB2 = (Uint16)(EPCountB2);

    //INV3
    EPCountA3 = PeriodCountmax * (0.5 + 0.5 * Vref3*Vdcinv);
    EPCountB3 = PeriodCountmax * (0.5 - 0.5 * Vref3*Vdcinv);

    EPCountA3 = EPCountA3 >= PeriodCountmax ? PeriodCountmax : (EPCountA3 <= 0 ? 0 : EPCountA3);
    EPCountB3 = EPCountB3 >= PeriodCountmax ? PeriodCountmax : (EPCountB3 <= 0 ? 0 : EPCountB3);

    EPwmCountA3 = (Uint16)(EPCountA3);
    EPwmCountB3 = (Uint16)(EPCountB3); 


    //  Inverter Enable
    if(Flag_Inv1 == 1) {
        EPwm11Regs.CMPA.bit.CMPA = EPwmCountA; //EPwm1A
        EPwm11Regs.CMPB.bit.CMPB = EPwmCountB; //EPwm1B

    }
    else {
        EPwm11Regs.CMPA.bit.CMPA = 0; //EPwm1A
        EPwm11Regs.CMPB.bit.CMPB = 0; //EPwm1B
    }

    if(Flag_Inv2 == 1) {
        EPwm9Regs.CMPA.bit.CMPA = EPwmCountA2; //EPwm2A
        EPwm9Regs.CMPB.bit.CMPB = EPwmCountB2; //EPwm2B

    }
    else {
        EPwm9Regs.CMPA.bit.CMPA = 0; //EPwm2A
        EPwm9Regs.CMPB.bit.CMPB = 0; //EPwm2B
    }

    if(Flag_Inv3 == 1) {
        EPwm7Regs.CMPA.bit.CMPA = EPwmCountA3; //EPwm3A
        EPwm7Regs.CMPB.bit.CMPB = EPwmCountB3; //EPwm3B

    }
    else {
        EPwm7Regs.CMPA.bit.CMPA = 0; //EPwm3A
        EPwm7Regs.CMPB.bit.CMPB = 0; //EPwm3B
    }




////////////////////////////////////////////////////////

    // Gating Counter Value Update -->

    if(EPwm1Regs.TBSTS.bit.CTRDIR==cc_dir)
    {
        cc_timer[0] = EPwm1Regs.TBCTR;
        cc_timer[1] = EPwm2Regs.TBCTR;
        cc_timer[2] = EPwm3Regs.TBCTR;
        cc_timer[3] = EPwm4Regs.TBCTR;
        cc_timer[4] = EPwm5Regs.TBCTR;
        cc_timer[5] = EPwm6Regs.TBCTR;
        cc_timer[6] = EPwm7Regs.TBCTR;
        cc_timer[7] = EPwm8Regs.TBCTR;
        cc_timer[8] = EPwm9Regs.TBCTR;
        cc_timer[9] = EPwm10Regs.TBCTR;
        cc_timer[10] = EPwm11Regs.TBCTR;
        cc_timer[11] = EPwm12Regs.TBCTR;
    }

    // <-- User Code Start!!!




    // User Code End!!! -->

    // <-- Timer stop
    CPUTimer_stopTimer(CPUTIMER0_BASE);
    ccTimePresent = CPUTimer_getTimerCount(CPUTIMER0_BASE);
    ccTime_us = 1000000.*(float)SYS_CLK_PRD*(ccTimeInit - ccTimePresent);
    CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
    // Timer stop -->

    EPwm1Regs.ETCLR.bit.SOCA = 1; //clear SOCA flag
    EPwm1Regs.ETCLR.bit.INT = 1; //clear INT flag
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}
