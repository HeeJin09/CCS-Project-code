/*
 * cc.h
 *
 *  Created on: 2018. 3. 25.
 *      Author: eunso
 */

#ifndef CC_H_
#define CC_H_

#include "variables.h"

extern interrupt void cc_isr(void);


#endif /* CC_H_ */
