
#ifndef CAN_LIB_
#define CAN_LIB_

#include "variables.h"

#define SDO_RXID_BASELINE 0x0600
#define SDO_TXID_BASELINE 0x0580
#define PDO_RXID_BASELINE 0x0500
#define PDO_TXID_BASELINE 0x0480

#define DEVICE_ID 0x02
 
#define CAN_ATTRIBUTION_READ_1BYTE 0x4F
#define CAN_ATTRIBUTION_READ_2BYTE 0x4B
#define CAN_ATTRIBUTION_READ_4BYTE 0x43

#define CAN_ATTRIBUTION_WRITE_1BYTE 0x2F
#define CAN_ATTRIBUTION_WRITE_2BYTE 0x2B
#define CAN_ATTRIBUTION_WRITE_4BYTE 0x23

#define INDEX_FORCECONTROL 0x6040


typedef union
{
	struct
	{
        unsigned char attrib;
		unsigned char index[2];
		unsigned char subindex;
		unsigned char data[4];
	}info;
	unsigned char  value[8];
}CAN_PACKET;

typedef union {
	unsigned char 	uint8Value[4];
	unsigned short 	uint16Value[2];
	unsigned long 	uint32Value;
}DATA_OBJECT;

// extern interrupt void CANopen(void);

#endif CAN_LIB_
