/*
 * variables.c
 *
 *  Created on: 2018. 8. 3.
 *      Author: PowerElabLAPTOP1
 */
#include "variables.h"



uint32_t ccTimeInit = 0, ccTimePresent = 0;
float ccTime_us = 0.;



Uint16 AdcaResults[6] = {0, 0, 0, 0, 0, 0};
Uint16 AdcbResults[6] = {0, 0, 0, 0, 0, 0};
Uint16 AdccResults[6] = {0, 0, 0, 0, 0, 0};
Uint16 AdcdResults[6] = {0, 0, 0, 0, 0, 0};

double AdcaValues[6]  = {0., 0., 0., 0., 0., 0.};
double AdcbValues[6]  = {0., 0., 0., 0., 0., 0.};
double AdccValues[6]  = {0., 0., 0., 0., 0., 0.};
double AdcdValues[6]  = {0., 0., 0., 0., 0., 0.};


// Gating values
Uint16 GD1enable = 0, GD2enable = 0, GD3enable = 0, GD4enable = 0;
Uint16 GD1_Epwm1Count = 0, GD1_Epwm2Count = 0, GD1_Epwm3Count = 0;
Uint16 GD2_Epwm1Count = 0, GD2_Epwm2Count = 0, GD2_Epwm3Count = 0;
Uint16 GD3_Epwm1Count = 0, GD3_Epwm2Count = 0, GD3_Epwm3Count = 0;
Uint16 GD4_Epwm1Count = 0, GD4_Epwm2Count = 0, GD4_Epwm3Count = 0;

FLAG Flags;
void InitFlags(void)
{
    Flags.Fault = 0;
}
// Fault
Uint16 GD1Fault = 0x00, GD2Fault = 0x00, GD3Fault = 0x00, GD4Fault = 0x00;


// <-- User Code Start!!!

double Vref = 0., Vref2 = 0., Vref3 = 0., Vref4 = 0., Vref5 = 0.;
double Vdcinv = 0.;
double EPCountA = 0., EPCountB = 0., EPCountA2 = 0., EPCountB2 = 0., EPCountA3 = 0., EPCountB3 = 0.;
double EPCountA4 = 0., EPCountB4 = 0., EPCountA5 = 0., EPCountB5 = 0.;

Uint16 EPwmCountA = 0, EPwmCountB = 0, EPwmCountA2 = 0, EPwmCountB2 = 0, EPwmCountA3 = 0, EPwmCountB3 = 0;
Uint16 EPwmCountA4 = 0, EPwmCountB4 = 0, EPwmCountA5 = 0, EPwmCountB5 = 0;
Uint16 PeriodCountmax = 10000;
Uint16 Flag_Inv1 = 0, Flag_Inv2 = 0, Flag_Inv3 = 0, Flag_Inv4 = 0, Flag_Inv5 = 0;

double I_Inv1_1 = 0., I_Inv1_2 = 0., I_Inv2_1 = 0., I_Inv2_2 = 0., I_Inv3_1 = 0., I_Inv3_2 = 0., Motor_Speed = 0.;

double Theta_hat_pre = 0., Theta_hat = 0., Err_Theta = 0., W_hat_integ = 0., W_hat = 0.;
double Theta_hat2_pre = 0., Theta_hat2 = 0., Err_Theta2 = 0., W_hat2_integ = 0., W_hat2 = 0.;
double Theta_hat3_pre = 0., Theta_hat3 = 0., Err_Theta3 = 0., W_hat3_integ = 0., W_hat3 = 0.;
double test_mc = 0;
double RPM_filter = 0., RPM_filter2 = 0., RPM_filter3 = 0.;
double Kp_sf = 0., Ki_sf = 0., zeta = 0.707, Wsf = TWOPI * 200.;    
double ENC_Counter = 0., ENC_Counter2 = 0., ENC_Counter3 = 0.;
double ENC_CAP_period = 0.;

//Position control
double Angle = 0., Theta_Ref = 0., Theta_FB = 0.;
double Angle2 = 0., Theta_Ref2 = 0., Theta_FB2 = 0.;
double Angle3 = 0., Theta_Ref3 = 0., Theta_FB3 = 0.;

double Err_Theta_pc = 0., Err_Theta_pc2 = 0., Err_Theta_pc3 = 0.;

double Kp_pc = 0.;

double Err_Theta_pc_pd_pre = 0., Err_Theta_pc_pd = 0., Err_Theta_pc_dot = 0., Tau = 0., Kd_pc = 0., I_Ref_pd = 0.;
Uint16 Flag_pd = 0, Cnt_pd = 0, Cnt_pd2 = 0, Cnt_pd3 = 0;
double Ki_sc_ratio = 5., Ka_cc_ratio = 1., Ka_sc_ratio = 1., Kad_sc = 0.;

//speed control
double Kp_sc = 0., Ki_sc = 0., Kp_cc = 0., Ki_cc = 0., Ka_sc = 0., Ka_cc = 0.;

double I_Ref = 0., Te_Ref = 0., V_Ref = 0.;
double I_Ref2 = 0., Te_Ref2 = 0., V_Ref2 = 0.;
double I_Ref3 = 0., Te_Ref3 = 0., V_Ref3 = 0.;
double Te_Ref4 = 0., Te_Ref5 = 0., I_Ref4 = 0., I_Ref5 = 0., V_Ref4 = 0., V_Ref5 = 0.;

double Wrm = 0., Wrm_Ref = 0., Wrm2 = 0., Wrm_Ref2 = 0., Wrm3 = 0., Wrm_Ref3 = 0.;
double Wc_sc = TWOPI * 100., Wcc = TWOPI * 500.;
double J = 0.12e-7, Kt = 4.39e-3, Ls = 168e-3, Rs = 12.5;
int GearRatio = 16.;

double Err_Wrm = 0., Err_I_Ref = 0., Err_V_Ref = 0., Err_Te = 0.;
double Err_Wrm2 = 0., Err_I_Ref2 = 0., Err_V_Ref2 = 0., Err_Te2 = 0.;
double Err_Wrm3 = 0., Err_I_Ref3 = 0., Err_V_Ref3 = 0., Err_Te3 = 0.;
double Err_I_Ref4 = 0., Err_V_Ref4 = 0., Err_I_Ref5 = 0., Err_V_Ref5 = 0.;

double Te_Ref_integ = 0., V_Ref_integ = 0.;
double Te_Ref2_integ = 0., V_Ref2_integ = 0.;
double Te_Ref3_integ = 0., V_Ref3_integ = 0.;
double Te_Ref4_integ = 0., V_Ref4_integ = 0.;
double Te_Ref5_integ = 0., V_Ref5_integ = 0.;

double V_Ref_Sat = 0., V_Ref2_Sat = 0., V_Ref3_Sat = 0., V_Ref4_Sat = 0., V_Ref5_Sat = 0.;
double I_Ref_Sat = 0., I_Ref2_Sat = 0., I_Ref3_Sat = 0., I_Ref4_Sat = 0., I_Ref5_Sat = 0.;
double Vrated = 8., Irated = 0.23, Wrmrated = 588., I_max = 0.55;

double Wrpm = 0., RPM_Ref = 0.;
double Wrpm2 = 0., RPM_Ref2 = 0.;
double Wrpm3 = 0., RPM_Ref3 = 0.;

int Flag_sc = 0.;
double I_FB = 0., I_FB2 = 0., I_FB3 = 0., I_FB4 = 0., I_FB5 = 0.;

//CAN
unsigned char TXMsgData[8], RXMsgData[8], txd[4], index_tx[2];   //8 bit

// 3 phase system parameter
SYSTEM_3PH INV1, INV2, INV3;
/////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////
static const uint16_t g_ui16CANBitValues[] =
{
    0x1100, // TSEG2 2, TSEG1 2, SJW 1, Divide 5
    0x1200, // TSEG2 2, TSEG1 3, SJW 1, Divide 6
    0x2240, // TSEG2 3, TSEG1 3, SJW 2, Divide 7
    0x2340, // TSEG2 3, TSEG1 4, SJW 2, Divide 8
    0x3340, // TSEG2 4, TSEG1 4, SJW 2, Divide 9
    0x3440, // TSEG2 4, TSEG1 5, SJW 2, Divide 10
    0x3540, // TSEG2 4, TSEG1 6, SJW 2, Divide 11
    0x3640, // TSEG2 4, TSEG1 7, SJW 2, Divide 12
    0x3740  // TSEG2 4, TSEG1 8, SJW 2, Divide 13
};

static bool
CANBaseValid(uint32_t ui32Base)
{
    return((ui32Base == CANA_BASE) || (ui32Base == CANB_BASE));
}

static void
CANDataRegRead(unsigned char *pucData, uint32_t *pui32Register, int16_t iSize)
{
    int16_t iIdx;
    unsigned char * pucRegister = (unsigned char *) pui32Register;

    // Loop always copies 1 or 2 bytes per iteration.
    for(iIdx = 0; iIdx < iSize; iIdx++ )
    {
        // Read out the data
        pucData[iIdx] = HWREGB(pucRegister++);
    }
}

static void
CANDataRegWrite(unsigned char *pucData, uint32_t *pui32Register, int16_t iSize)
{
    int16_t iIdx;
    unsigned char * pucRegister = (unsigned char *) pui32Register;

    // Loop always copies 1 or 2 bytes per iteration.
    for(iIdx = 0; iIdx < iSize; iIdx++ )
    {
        // Write out the data 8 bits at a time.
        HWREGB(pucRegister++) = pucData[iIdx];
    }
}

uint32_t
CANBitRateSet(uint32_t ui32Base, uint32_t ui32SourceClock, uint32_t ui32BitRate)
{
    uint32_t ui32DesiredRatio;
    uint32_t ui32CANBits;
    uint32_t ui32PreDivide;
    uint32_t ui32RegValue;
    uint16_t ui16CANCTL;

    ASSERT(ui32BitRate != 0);

    // Calculate the desired clock rate.
    ui32DesiredRatio = ui32SourceClock / ui32BitRate;

    // If the ratio of CAN bit rate to processor clock is too small or too
    // large then return 0 indicating that no bit rate was set.
    ASSERT(ui32DesiredRatio <= (CAN_MAX_PRE_DIVISOR * CAN_MAX_BIT_DIVISOR));
    ASSERT(ui32DesiredRatio >= (CAN_MIN_PRE_DIVISOR * CAN_MIN_BIT_DIVISOR));

    // Make sure that the Desired Ratio is not too large.  This enforces the
    // requirement that the bit rate is larger than requested.
    if((ui32SourceClock / ui32DesiredRatio) > ui32BitRate)
    {
        ui32DesiredRatio += 1;
    }

    // Check all possible values to find a matching value.
    while(ui32DesiredRatio <= CAN_MAX_PRE_DIVISOR * CAN_MAX_BIT_DIVISOR)
    {
        // Loop through all possible CAN bit divisors.
        for(ui32CANBits = CAN_MAX_BIT_DIVISOR;
            ui32CANBits >= CAN_MIN_BIT_DIVISOR;
            ui32CANBits--)
        {
            // For a given CAN bit divisor save the pre divisor.
            ui32PreDivide = ui32DesiredRatio / ui32CANBits;

            // If the calculated divisors match the desired clock ratio then
            // return these bit rate and set the CAN bit timing.
            if((ui32PreDivide * ui32CANBits) == ui32DesiredRatio)
            {
                // Start building the bit timing value by adding the bit timing
                // in time quanta.
                ui32RegValue =
                    g_ui16CANBitValues[ui32CANBits - CAN_MIN_BIT_DIVISOR];

                // To set the bit timing register, the controller must be
                // placed
                // in init mode (if not already), and also configuration change
                // bit enabled.  The state of the register should be saved
                // so it can be restored.

                ui16CANCTL = HWREGH(ui32Base + CAN_O_CTL);
                HWREGH(ui32Base + CAN_O_CTL) = ui16CANCTL | CAN_CTL_INIT |
                                               CAN_CTL_CCE;

                // Now add in the pre-scalar on the bit rate.
                ui32RegValue |= ((ui32PreDivide - 1) & CAN_BTR_BRP_M) |
                				(((ui32PreDivide - 1) << 10) & CAN_BTR_BRPE_M);

                // Set the clock bits in the and the bits of the
                // pre-scalar.
                HWREGH(ui32Base + CAN_O_BTR) = (ui32RegValue &
                                                CAN_REG_WORD_MASK);
                HWREGH(ui32Base + CAN_O_BTR + 2) = (ui32RegValue >> 16);

                // Restore the saved CAN Control register.
                HWREGH(ui32Base + CAN_O_CTL) = ui16CANCTL;

                // Return the computed bit rate.
                return(ui32SourceClock / ( ui32PreDivide * ui32CANBits));
            }
        }

        // Move the divisor up one and look again.  Only in rare cases are
        // more than 2 loops required to find the value.
        ui32DesiredRatio++;
    }
    return(0);
}

void CANClkSourceSelect(uint32_t ui32Base, uint16_t ui16Source)
{
    EALLOW;
    switch(ui32Base)
    {
        case CANA_BASE:
        {
            ClkCfgRegs.CLKSRCCTL2.bit.CANABCLKSEL = ui16Source;
        }

        case CANB_BASE:
        {
            ClkCfgRegs.CLKSRCCTL2.bit.CANBBCLKSEL = ui16Source;
        }

        default:
            break;
    }
    EDIS;
}

void
CANEnable(uint32_t ui32Base)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // Clear the init bit in the control register.
    HWREGH(ui32Base + CAN_O_CTL) = HWREGH(ui32Base + CAN_O_CTL) &
                                   ~CAN_CTL_INIT;
}

void
CANInit(uint32_t ui32Base)
{
    int16_t iMsg;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // Place CAN controller in init state, regardless of previous state.  This
    // will put controller in idle, and allow the message object RAM to be
    // programmed.

    HWREGH(ui32Base + CAN_O_CTL) = CAN_CTL_INIT;
    HWREGH(ui32Base + CAN_O_CTL) = CAN_CTL_SWR;

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
    {
    }

    // Clear the message value bit in the arbitration register.  This indicates
    // the message is not valid and is a "safe" condition to leave the message
    // object.  The same arb reg is used to program all the message objects.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = (CAN_IF1CMD_DIR | CAN_IF1CMD_ARB |
                                           CAN_IF1CMD_CONTROL) >> 16;
    HWREGH(ui32Base + CAN_O_IF1ARB) = 0;
    HWREGH(ui32Base + CAN_O_IF1ARB + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF1MCTL) = 0;
    HWREGH(ui32Base + CAN_O_IF1MCTL + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF2CMD + 2) = (CAN_IF2CMD_DIR | CAN_IF2CMD_ARB |
                                           CAN_IF2CMD_CONTROL) >> 16;
    HWREGH(ui32Base + CAN_O_IF2ARB) = 0;
    HWREGH(ui32Base + CAN_O_IF2ARB + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF2MCTL) = 0;
    HWREGH(ui32Base + CAN_O_IF2MCTL + 2) = 0;

    // Loop through to program all 32 message objects
    for(iMsg = 1; iMsg <= 32; iMsg+=2)
    {
        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF1CMD) = iMsg;

        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF2CMD) = iMsg + 1;
    }

    // Make sure that the interrupt and new data flags are updated for the
    // message objects.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = (CAN_IF1CMD_TXRQST |
                                           CAN_IF1CMD_CLRINTPND) >> 16;
    HWREGH(ui32Base + CAN_O_IF2CMD + 2) = (CAN_IF2CMD_TXRQST |
                                           CAN_IF2CMD_CLRINTPND) >> 16;

    // Loop through to program all 32 message objects
    for(iMsg = 1; iMsg <= 32; iMsg+=2)
    {
        // Wait for busy bit to clear.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF1CMD) = iMsg;

        // Wait for busy bit to clear.
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF2CMD) = iMsg + 1;
    }

    // Acknowledge any pending status interrupts.
    HWREG(ui32Base + CAN_O_ES);
}

void
CANIntClear(uint32_t ui32Base, uint32_t ui32IntClr)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntClr == CAN_INT_INT0ID_STATUS) ||
           ((ui32IntClr>=1) && (ui32IntClr <=32)));

    if(ui32IntClr == CAN_INT_INT0ID_STATUS)
    {
        // Simply read and discard the status to clear the interrupt.
        HWREG(ui32Base + CAN_O_ES);
    }
    else
    {
        // Wait to be sure that this interface is not busy.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Only change the interrupt pending state by setting only the
        // CAN_IF1CMD_CLRINTPND bit.
        HWREGH(ui32Base + CAN_O_IF1CMD + 2) = CAN_IF1CMD_CLRINTPND >> 16;

        // Send the clear pending interrupt command to the CAN controller.
        HWREGH(ui32Base + CAN_O_IF1CMD) = ui32IntClr & CAN_IF1CMD_MSG_NUM_M;

        // Wait to be sure that this interface is not busy.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }
    }
}

void
CANMessageGet(uint32_t ui32Base, uint32_t ui32ObjID, tCANMsgObject *pMsgObject,
              bool bClrPendingInt)
{
    uint32_t ui32CmdMaskReg;
    uint32_t ui32MaskReg;
    uint32_t ui32ArbReg;
    uint32_t ui32MsgCtrl;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32ObjID <= 32) && (ui32ObjID != 0));

    // This is always a read to the Message object as this call is setting a
    // message object.
    ui32CmdMaskReg = (CAN_IF2CMD_DATA_A | CAN_IF2CMD_DATA_B |
                      CAN_IF2CMD_CONTROL | CAN_IF2CMD_MASK | CAN_IF2CMD_ARB);

    // Clear a pending interrupt and new data in a message object.
    if(bClrPendingInt)
    {
        ui32CmdMaskReg |= CAN_IF2CMD_CLRINTPND | CAN_IF2CMD_TXRQST;
    }

    // Set up the request for data from the message object.
    HWREGH(ui32Base + CAN_O_IF2CMD + 2) =  ui32CmdMaskReg >> 16;

    // Transfer the message object to the message object specified by ui32ObjID.
    HWREGH(ui32Base + CAN_O_IF2CMD) = ui32ObjID & CAN_IF2CMD_MSG_NUM_M;

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
    {
    }

    // Read out the IF Registers.
    ui32MaskReg = HWREG(ui32Base + CAN_O_IF2MSK);
    ui32ArbReg = HWREG(ui32Base + CAN_O_IF2ARB);
    ui32MsgCtrl = HWREG(ui32Base + CAN_O_IF2MCTL);
    pMsgObject->ui32Flags = MSG_OBJ_NO_FLAGS;

    // Determine if this is a remote frame by checking the TXRQST and DIR bits.
    if((!(ui32MsgCtrl & CAN_IF2MCTL_TXRQST) && (ui32ArbReg & CAN_IF2ARB_DIR)) ||
       ((ui32MsgCtrl & CAN_IF2MCTL_TXRQST) && (!(ui32ArbReg & CAN_IF2ARB_DIR))))
    {
        pMsgObject->ui32Flags |= MSG_OBJ_REMOTE_FRAME;
    }

    // Get the identifier out of the register, the format depends on size of
    // the mask.
    if(ui32ArbReg & CAN_IF2ARB_XTD)
    {
        // Set the 29 bit version of the Identifier for this message object.
        pMsgObject->ui32MsgID = ui32ArbReg & CAN_IF2ARB_ID_M;

        pMsgObject->ui32Flags |= MSG_OBJ_EXTENDED_ID;
    }
    else
    {
        // The Identifier is an 11 bit value.
        pMsgObject->ui32MsgID = (ui32ArbReg &
                                 CAN_IF2ARB_STD_ID_M) >> CAN_IF2ARB_STD_ID_S;
    }

    // Indicate that we lost some data.
    if(ui32MsgCtrl & CAN_IF2MCTL_MSGLST)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_DATA_LOST;
    }

    // Set the flag to indicate if ID masking was used.
    if(ui32MsgCtrl & CAN_IF2MCTL_UMASK)
    {
        if(ui32ArbReg & CAN_IF2ARB_XTD)
        {
            // The Identifier Mask is assumed to also be a 29 bit value.
            pMsgObject->ui32MsgIDMask = (ui32MaskReg & CAN_IF2MSK_MSK_M);

            // If this is a fully specified Mask and a remote frame then don't
            // set the MSG_OBJ_USE_ID_FILTER because the ID was not really
            // filtered.
            if((pMsgObject->ui32MsgIDMask != 0x1fffffff) ||
               ((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0))
            {
                pMsgObject->ui32Flags |= MSG_OBJ_USE_ID_FILTER;
            }
        }
        else
        {
            // The Identifier Mask is assumed to also be an 11 bit value.
            pMsgObject->ui32MsgIDMask = ((ui32MaskReg & CAN_IF2MSK_MSK_M) >>
                                         18);

            // If this is a fully specified Mask and a remote frame then don't
            // set the MSG_OBJ_USE_ID_FILTER because the ID was not really
            // filtered.
            if((pMsgObject->ui32MsgIDMask != 0x7ff) ||
               ((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0))
            {
                pMsgObject->ui32Flags |= MSG_OBJ_USE_ID_FILTER;
            }
        }

        // Indicate if the extended bit was used in filtering.
        if(ui32MaskReg & CAN_IF2MSK_MXTD)
        {
            pMsgObject->ui32Flags |= MSG_OBJ_USE_EXT_FILTER;
        }

        // Indicate if direction filtering was enabled.
        if(ui32MaskReg & CAN_IF2MSK_MDIR)
        {
            pMsgObject->ui32Flags |= MSG_OBJ_USE_DIR_FILTER;
        }
    }

    // Set the interrupt flags.
    if(ui32MsgCtrl & CAN_IF2MCTL_TXIE)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_TX_INT_ENABLE;
    }
    if(ui32MsgCtrl & CAN_IF2MCTL_RXIE)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_RX_INT_ENABLE;
    }

    // See if there is new data available.
    if(ui32MsgCtrl & CAN_IF2MCTL_NEWDAT)
    {
        // Get the amount of data needed to be read.
        pMsgObject->ui32MsgLen = (ui32MsgCtrl & CAN_IF2MCTL_DLC_M);

        // Don't read any data for a remote frame, there is nothing valid in
        // that buffer anyway.
        if((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0)
        {
            // Read out the data from the CAN registers.
            CANDataRegRead(pMsgObject->pucMsgData,
                           (uint32_t *)(ui32Base + CAN_O_IF2DATA),
                           pMsgObject->ui32MsgLen);
        }

        // Now clear out the new data flag.
        HWREGH(ui32Base + CAN_O_IF2CMD + 2) = CAN_IF2CMD_TXRQST >> 16;

        // Transfer the message object to the message object specified by
        // ui32ObjID.
        HWREGH(ui32Base + CAN_O_IF2CMD) = ui32ObjID & CAN_IF2CMD_MSG_NUM_M;

        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Indicate that there is new data in this message.
        pMsgObject->ui32Flags |= MSG_OBJ_NEW_DATA;
    }
    else
    {
        // Along with the MSG_OBJ_NEW_DATA not being set the amount of data
        // needs to be set to zero if none was available.
        pMsgObject->ui32MsgLen = 0;
    }
}

void
CANMessageSet(uint32_t ui32Base, uint32_t ui32ObjID, tCANMsgObject *pMsgObject,
              tMsgObjType eMsgType)
{
    uint32_t ui32CmdMaskReg;
    uint32_t ui32MaskReg;
    uint32_t ui32ArbReg;
    uint32_t ui32MsgCtrl;
    bool bTransferData;
    bool bUseExtendedID;

    bTransferData = 0;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32ObjID <= 32) && (ui32ObjID != 0));
    ASSERT((eMsgType == MSG_OBJ_TYPE_TX) ||
           (eMsgType == MSG_OBJ_TYPE_TX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_RX) ||
           (eMsgType == MSG_OBJ_TYPE_RX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_TX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_RXTX_REMOTE));

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
    {
    }

    // See if we need to use an extended identifier or not.
    if((pMsgObject->ui32MsgID > CAN_MAX_11BIT_MSG_ID) ||
       (pMsgObject->ui32Flags & MSG_OBJ_EXTENDED_ID))
    {
        bUseExtendedID = 1;
    }
    else
    {
        bUseExtendedID = 0;
    }

    // This is always a write to the Message object as this call is setting a
    // message object.  This call will also always set all size bits so it sets
    // both data bits.  The call will use the CONTROL register to set control
    // bits so this bit needs to be set as well.
    ui32CmdMaskReg = (CAN_IF1CMD_DIR | CAN_IF1CMD_DATA_A | CAN_IF1CMD_DATA_B |
                      CAN_IF1CMD_CONTROL);

    // Initialize the values to a known state before filling them in based on
    // the type of message object that is being configured.
    ui32ArbReg = 0;
    ui32MsgCtrl = 0;
    ui32MaskReg = 0;

    switch(eMsgType)
    {
    // Transmit message object.
    case MSG_OBJ_TYPE_TX:
    {
        // Set the TXRQST bit and the reset the rest of the register.
        ui32MsgCtrl |= CAN_IF1MCTL_TXRQST;
        ui32ArbReg = CAN_IF1ARB_DIR;
        bTransferData = 1;
        break;
    }

    // Transmit remote request message object
    case MSG_OBJ_TYPE_TX_REMOTE:
    {
        // Set the TXRQST bit and the reset the rest of the register.
        ui32MsgCtrl |= CAN_IF1MCTL_TXRQST;
        ui32ArbReg = 0;
        break;
    }

    // Receive message object.
    case MSG_OBJ_TYPE_RX:
    {
        // This clears the DIR bit along with everything else.  The TXRQST
        // bit was cleared by defaulting ui32MsgCtrl to 0.
        ui32ArbReg = 0;
        break;
    }

    // Receive remote request message object.
    case MSG_OBJ_TYPE_RX_REMOTE:
    {
        // The DIR bit is set to one for remote receivers.  The TXRQST bit
        // was cleared by defaulting ui32MsgCtrl to 0.
        ui32ArbReg = CAN_IF1ARB_DIR;

        // Set this object so that it only indicates that a remote frame
        // was received and allow for software to handle it by sending back
        // a data frame.
        ui32MsgCtrl = CAN_IF1MCTL_UMASK;

        // Use the full Identifier by default.
        ui32MaskReg = CAN_IF1MSK_MSK_M;

        // Make sure to send the mask to the message object.
        ui32CmdMaskReg |= CAN_IF1CMD_MASK;
        break;
    }

    // Remote frame receive remote, with auto-transmit message object.
    case MSG_OBJ_TYPE_RXTX_REMOTE:
    {
        // Oddly the DIR bit is set to one for remote receivers.
        ui32ArbReg = CAN_IF1ARB_DIR;

        // Set this object to auto answer if a matching identifier is seen.
        ui32MsgCtrl = CAN_IF1MCTL_RMTEN | CAN_IF1MCTL_UMASK;

        // The data to be returned needs to be filled in.
        bTransferData = 1;
        break;
    }

    // This case should never happen due to the ASSERT statement at the
    // beginning of this function.
    default:
    {
        return;
    }
    }

    // Configure the Mask Registers.
    if(pMsgObject->ui32Flags & MSG_OBJ_USE_ID_FILTER)
    {
        if(bUseExtendedID)
        {
            // Set the 29 bits of Identifier mask that were requested.
            ui32MaskReg = pMsgObject->ui32MsgIDMask & CAN_IF1MSK_MSK_M;
        }
        else
        {

            // Put the 11 bit Mask Identifier into the upper bits of the field
            // in the register.
            ui32MaskReg = ((pMsgObject->ui32MsgIDMask << CAN_IF1ARB_STD_ID_S) &
                           CAN_IF1ARB_STD_ID_M);
        }
    }

    // If the caller wants to filter on the extended ID bit then set it.
    if((pMsgObject->ui32Flags & MSG_OBJ_USE_EXT_FILTER) ==
       MSG_OBJ_USE_EXT_FILTER)
    {
        ui32MaskReg |= CAN_IF1MSK_MXTD;
    }

    // The caller wants to filter on the message direction field.
    if((pMsgObject->ui32Flags & MSG_OBJ_USE_DIR_FILTER) ==
       MSG_OBJ_USE_DIR_FILTER)
    {
        ui32MaskReg |= CAN_IF1MSK_MDIR;
    }

    if(pMsgObject->ui32Flags & (MSG_OBJ_USE_ID_FILTER | MSG_OBJ_USE_DIR_FILTER |
                              MSG_OBJ_USE_EXT_FILTER))
    {
        // Set the UMASK bit to enable using the mask register.
        ui32MsgCtrl |= CAN_IF1MCTL_UMASK;

        // Set the MASK bit so that this gets transferred to the Message
        // Object.
        ui32CmdMaskReg |= CAN_IF1CMD_MASK;
    }

    // Set the Arb bit so that this gets transferred to the Message object.
    ui32CmdMaskReg |= CAN_IF1CMD_ARB;

    // Configure the Arbitration registers.
    if(bUseExtendedID)
    {
        // Set the 29 bit version of the Identifier for this message object.
        // Mark the message as valid and set the extended ID bit.
        ui32ArbReg |= (pMsgObject->ui32MsgID & CAN_IF1ARB_ID_M) |
                      CAN_IF1ARB_MSGVAL | CAN_IF1ARB_XTD;
    }
    else
    {
        // Set the 11 bit version of the Identifier for this message object.
        // The lower 18 bits are set to zero.
        // Mark the message as valid.
        ui32ArbReg |= ((pMsgObject->ui32MsgID << CAN_IF1ARB_STD_ID_S) &
                       CAN_IF1ARB_STD_ID_M) | CAN_IF1ARB_MSGVAL;
    }

    // Set the data length since this is set for all transfers.  This is also a
    // single transfer and not a FIFO transfer so set EOB bit.
    ui32MsgCtrl |= (pMsgObject->ui32MsgLen & CAN_IF1MCTL_DLC_M);

    // Mark this as the last entry if this is not the last entry in a FIFO.
    if((pMsgObject->ui32Flags & MSG_OBJ_FIFO) == 0)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_EOB;
    }

    // Enable transmit interrupts if they should be enabled.
    if(pMsgObject->ui32Flags & MSG_OBJ_TX_INT_ENABLE)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_TXIE;
    }

    // Enable receive interrupts if they should be enabled.
    if(pMsgObject->ui32Flags & MSG_OBJ_RX_INT_ENABLE)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_RXIE;
    }

    // Write the data out to the CAN Data registers if needed.
    if(bTransferData)
    {
        CANDataRegWrite(pMsgObject->pucMsgData,
                        (uint32_t *)(ui32Base + CAN_O_IF1DATA),
                        pMsgObject->ui32MsgLen);
    }

    // Write out the registers to program the message object.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = ui32CmdMaskReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1MSK) = ui32MaskReg & CAN_REG_WORD_MASK;
    HWREGH(ui32Base + CAN_O_IF1MSK + 2) = ui32MaskReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1ARB) = ui32ArbReg & CAN_REG_WORD_MASK;
    HWREGH(ui32Base + CAN_O_IF1ARB + 2) = ui32ArbReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1MCTL) = ui32MsgCtrl & CAN_REG_WORD_MASK;

    // Transfer the message object to the message object specific by ui32ObjID.
    HWREGH(ui32Base + CAN_O_IF1CMD) = ui32ObjID & CAN_IF1CMD_MSG_NUM_M;

    return;
}
/*

volatile uint32_t txMsgCount = 0;
volatile uint32_t rxMsgCount = 0;
volatile uint32_t errorFlag = 0;
Uint32	BackTicker;

void CANClkSourceSelect(uint32_t ui32Base, uint16_t ui16Source)
{
    EALLOW;
    switch(ui32Base)
    {
        case CANA_BASE:
        {
            ClkCfgRegs.CLKSRCCTL2.bit.CANABCLKSEL = ui16Source;
        }

        case CANB_BASE:
        {
            ClkCfgRegs.CLKSRCCTL2.bit.CANBBCLKSEL = ui16Source;
        }

        default:
            break;
    }
    EDIS;
}



volatile unsigned long g_ulMsgCount = 0; // A counter that keeps track of the
                                         // number of times the transmit was
                                         // successful.
volatile unsigned long g_bErrFlag = 0;   // A flag to indicate that some
                                         // transmission error occurred.

#ifdef DEBUG
static bool
CANBaseValid(uint32_t ui32Base)
{
    return(ui32Base == CANA_BASE);
}

#endif
void
CANEnable(uint32_t ui32Base)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // Clear the init bit in the control register.
    HWREGH(ui32Base + CAN_O_CTL) = HWREGH(ui32Base + CAN_O_CTL) &
                                   ~CAN_CTL_INIT;
}
static void
CANDataRegWrite(unsigned char *pucData, uint32_t *pui32Register, int16_t iSize)
{
    int16_t iIdx;
    unsigned char * pucRegister = (unsigned char *) pui32Register;

    // Loop always copies 1 or 2 bytes per iteration.
    for(iIdx = 0; iIdx < iSize; iIdx++ )
    {
        // Write out the data 8 bits at a time.
        HWREGB(pucRegister++) = pucData[iIdx];
    }
}
void
CANMessageSet(uint32_t ui32Base, uint32_t ui32ObjID, tCANMsgObject *pMsgObject,
              tMsgObjType eMsgType)
{
    uint32_t ui32CmdMaskReg;
    uint32_t ui32MaskReg;
    uint32_t ui32ArbReg;
    uint32_t ui32MsgCtrl;
    bool bTransferData;
    bool bUseExtendedID;

    bTransferData = 0;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32ObjID <= 32) && (ui32ObjID != 0));
    ASSERT((eMsgType == MSG_OBJ_TYPE_TX) ||
           (eMsgType == MSG_OBJ_TYPE_TX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_RX) ||
           (eMsgType == MSG_OBJ_TYPE_RX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_TX_REMOTE) ||
           (eMsgType == MSG_OBJ_TYPE_RXTX_REMOTE));

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
    {
    }

    // See if we need to use an extended identifier or not.
    if((pMsgObject->ui32MsgID > CAN_MAX_11BIT_MSG_ID) ||
       (pMsgObject->ui32Flags & MSG_OBJ_EXTENDED_ID))
    {
        bUseExtendedID = 1;
    }
    else
    {
        bUseExtendedID = 0;
    }

    // This is always a write to the Message object as this call is setting a
    // message object.  This call will also always set all size bits so it sets
    // both data bits.  The call will use the CONTROL register to set control
    // bits so this bit needs to be set as well.
    ui32CmdMaskReg = (CAN_IF1CMD_DIR | CAN_IF1CMD_DATA_A | CAN_IF1CMD_DATA_B |
                      CAN_IF1CMD_CONTROL);

    // Initialize the values to a known state before filling them in based on
    // the type of message object that is being configured.
    ui32ArbReg = 0;
    ui32MsgCtrl = 0;
    ui32MaskReg = 0;

    switch(eMsgType)
    {
    // Transmit message object.
    case MSG_OBJ_TYPE_TX:
    {
        // Set the TXRQST bit and the reset the rest of the register.
        ui32MsgCtrl |= CAN_IF1MCTL_TXRQST;
        ui32ArbReg = CAN_IF1ARB_DIR;
        bTransferData = 1;
        break;
    }

    // Transmit remote request message object
    case MSG_OBJ_TYPE_TX_REMOTE:
    {
        // Set the TXRQST bit and the reset the rest of the register.
        ui32MsgCtrl |= CAN_IF1MCTL_TXRQST;
        ui32ArbReg = 0;
        break;
    }

    // Receive message object.
    case MSG_OBJ_TYPE_RX:
    {
        // This clears the DIR bit along with everything else.  The TXRQST
        // bit was cleared by defaulting ui32MsgCtrl to 0.
        ui32ArbReg = 0;
        break;
    }

    // Receive remote request message object.
    case MSG_OBJ_TYPE_RX_REMOTE:
    {
        // The DIR bit is set to one for remote receivers.  The TXRQST bit
        // was cleared by defaulting ui32MsgCtrl to 0.
        ui32ArbReg = CAN_IF1ARB_DIR;

        // Set this object so that it only indicates that a remote frame
        // was received and allow for software to handle it by sending back
        // a data frame.
        ui32MsgCtrl = CAN_IF1MCTL_UMASK;

        // Use the full Identifier by default.
        ui32MaskReg = CAN_IF1MSK_MSK_M;

        // Make sure to send the mask to the message object.
        ui32CmdMaskReg |= CAN_IF1CMD_MASK;
        break;
    }

    // Remote frame receive remote, with auto-transmit message object.
    case MSG_OBJ_TYPE_RXTX_REMOTE:
    {
        // Oddly the DIR bit is set to one for remote receivers.
        ui32ArbReg = CAN_IF1ARB_DIR;

        // Set this object to auto answer if a matching identifier is seen.
        ui32MsgCtrl = CAN_IF1MCTL_RMTEN | CAN_IF1MCTL_UMASK;

        // The data to be returned needs to be filled in.
        bTransferData = 1;
        break;
    }

    // This case should never happen due to the ASSERT statement at the
    // beginning of this function.
    default:
    {
        return;
    }
    }

    // Configure the Mask Registers.
    if(pMsgObject->ui32Flags & MSG_OBJ_USE_ID_FILTER)
    {
        if(bUseExtendedID)
        {
            // Set the 29 bits of Identifier mask that were requested.
            ui32MaskReg = pMsgObject->ui32MsgIDMask & CAN_IF1MSK_MSK_M;
        }
        else
        {

            // Put the 11 bit Mask Identifier into the upper bits of the field
            // in the register.
            ui32MaskReg = ((pMsgObject->ui32MsgIDMask << CAN_IF1ARB_STD_ID_S) &
                           CAN_IF1ARB_STD_ID_M);
        }
    }

    // If the caller wants to filter on the extended ID bit then set it.
    if((pMsgObject->ui32Flags & MSG_OBJ_USE_EXT_FILTER) ==
       MSG_OBJ_USE_EXT_FILTER)
    {
        ui32MaskReg |= CAN_IF1MSK_MXTD;
    }

    // The caller wants to filter on the message direction field.
    if((pMsgObject->ui32Flags & MSG_OBJ_USE_DIR_FILTER) ==
       MSG_OBJ_USE_DIR_FILTER)
    {
        ui32MaskReg |= CAN_IF1MSK_MDIR;
    }

    if(pMsgObject->ui32Flags & (MSG_OBJ_USE_ID_FILTER | MSG_OBJ_USE_DIR_FILTER |
                              MSG_OBJ_USE_EXT_FILTER))
    {
        // Set the UMASK bit to enable using the mask register.
        ui32MsgCtrl |= CAN_IF1MCTL_UMASK;

        // Set the MASK bit so that this gets transferred to the Message
        // Object.
        ui32CmdMaskReg |= CAN_IF1CMD_MASK;
    }

    // Set the Arb bit so that this gets transferred to the Message object.
    ui32CmdMaskReg |= CAN_IF1CMD_ARB;

    // Configure the Arbitration registers.
    if(bUseExtendedID)
    {
        // Set the 29 bit version of the Identifier for this message object.
        // Mark the message as valid and set the extended ID bit.
        ui32ArbReg |= (pMsgObject->ui32MsgID & CAN_IF1ARB_ID_M) |
                      CAN_IF1ARB_MSGVAL | CAN_IF1ARB_XTD;
    }
    else
    {
        // Set the 11 bit version of the Identifier for this message object.
        // The lower 18 bits are set to zero.
        // Mark the message as valid.
        ui32ArbReg |= ((pMsgObject->ui32MsgID << CAN_IF1ARB_STD_ID_S) &
                       CAN_IF1ARB_STD_ID_M) | CAN_IF1ARB_MSGVAL;
    }

    // Set the data length since this is set for all transfers.  This is also a
    // single transfer and not a FIFO transfer so set EOB bit.
    ui32MsgCtrl |= (pMsgObject->ui32MsgLen & CAN_IF1MCTL_DLC_M);

    // Mark this as the last entry if this is not the last entry in a FIFO.
    if((pMsgObject->ui32Flags & MSG_OBJ_FIFO) == 0)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_EOB;
    }

    // Enable transmit interrupts if they should be enabled.
    if(pMsgObject->ui32Flags & MSG_OBJ_TX_INT_ENABLE)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_TXIE;
    }

    // Enable receive interrupts if they should be enabled.
    if(pMsgObject->ui32Flags & MSG_OBJ_RX_INT_ENABLE)
    {
        ui32MsgCtrl |= CAN_IF1MCTL_RXIE;
    }

    // Write the data out to the CAN Data registers if needed.
    if(bTransferData)
    {
        CANDataRegWrite(pMsgObject->pucMsgData,
                        (uint32_t *)(ui32Base + CAN_O_IF1DATA),
                        pMsgObject->ui32MsgLen);
    }

    // Write out the registers to program the message object.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = ui32CmdMaskReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1MSK) = ui32MaskReg & CAN_REG_WORD_MASK;
    HWREGH(ui32Base + CAN_O_IF1MSK + 2) = ui32MaskReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1ARB) = ui32ArbReg & CAN_REG_WORD_MASK;
    HWREGH(ui32Base + CAN_O_IF1ARB + 2) = ui32ArbReg >> 16;

    HWREGH(ui32Base + CAN_O_IF1MCTL) = ui32MsgCtrl & CAN_REG_WORD_MASK;

    // Transfer the message object to the message object specific by ui32ObjID.
    HWREGH(ui32Base + CAN_O_IF1CMD) = ui32ObjID & CAN_IF1CMD_MSG_NUM_M;

    return;
}
void
CANInit(uint32_t ui32Base)
{
    int16_t iMsg;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // Place CAN controller in init state, regardless of previous state.  This
    // will put controller in idle, and allow the message object RAM to be
    // programmed.

    HWREGH(ui32Base + CAN_O_CTL) = CAN_CTL_INIT;
    HWREGH(ui32Base + CAN_O_CTL) = CAN_CTL_SWR;

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
    {
    }

    // Clear the message value bit in the arbitration register.  This indicates
    // the message is not valid and is a "safe" condition to leave the message
    // object.  The same arb reg is used to program all the message objects.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = (CAN_IF1CMD_DIR | CAN_IF1CMD_ARB |
                                           CAN_IF1CMD_CONTROL) >> 16;
    HWREGH(ui32Base + CAN_O_IF1ARB) = 0;
    HWREGH(ui32Base + CAN_O_IF1ARB + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF1MCTL) = 0;
    HWREGH(ui32Base + CAN_O_IF1MCTL + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF2CMD + 2) = (CAN_IF2CMD_DIR | CAN_IF2CMD_ARB |
                                           CAN_IF2CMD_CONTROL) >> 16;
    HWREGH(ui32Base + CAN_O_IF2ARB) = 0;
    HWREGH(ui32Base + CAN_O_IF2ARB + 2) = 0;

    HWREGH(ui32Base + CAN_O_IF2MCTL) = 0;
    HWREGH(ui32Base + CAN_O_IF2MCTL + 2) = 0;

    // Loop through to program all 32 message objects
    for(iMsg = 1; iMsg <= 32; iMsg+=2)
    {
        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF1CMD) = iMsg;

        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF2CMD) = iMsg + 1;
    }

    // Make sure that the interrupt and new data flags are updated for the
    // message objects.
    HWREGH(ui32Base + CAN_O_IF1CMD + 2) = (CAN_IF1CMD_TXRQST |
                                           CAN_IF1CMD_CLRINTPND) >> 16;
    HWREGH(ui32Base + CAN_O_IF2CMD + 2) = (CAN_IF2CMD_TXRQST |
                                           CAN_IF2CMD_CLRINTPND) >> 16;

    // Loop through to program all 32 message objects
    for(iMsg = 1; iMsg <= 32; iMsg+=2)
    {
        // Wait for busy bit to clear.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF1CMD) = iMsg;

        // Wait for busy bit to clear.
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Initiate programming the message object
        HWREGH(ui32Base + CAN_O_IF2CMD) = iMsg + 1;
    }

    // Acknowledge any pending status interrupts.
    HWREG(ui32Base + CAN_O_ES);
}
static void
CANDataRegRead(unsigned char *pucData, uint32_t *pui32Register, int16_t iSize)
{
    int16_t iIdx;
    unsigned char * pucRegister = (unsigned char *) pui32Register;

    // Loop always copies 1 or 2 bytes per iteration.
    for(iIdx = 0; iIdx < iSize; iIdx++ )
    {
        // Read out the data
        pucData[iIdx] = HWREGB(pucRegister++);
    }
}
uint32_t
CANBitRateSet(uint32_t ui32Base, uint32_t ui32SourceClock, uint32_t ui32BitRate)
{
    uint32_t ui32DesiredRatio;
    uint32_t ui32CANBits;
    uint32_t ui32PreDivide;
    uint32_t ui32RegValue;
    uint16_t ui16CANCTL;

    ASSERT(ui32BitRate != 0);

    // Calculate the desired clock rate.
    ui32DesiredRatio = ui32SourceClock / ui32BitRate;

    // If the ratio of CAN bit rate to processor clock is too small or too
    // large then return 0 indicating that no bit rate was set.
    ASSERT(ui32DesiredRatio <= (CAN_MAX_PRE_DIVISOR * CAN_MAX_BIT_DIVISOR));
    ASSERT(ui32DesiredRatio >= (CAN_MIN_PRE_DIVISOR * CAN_MIN_BIT_DIVISOR));

    // Make sure that the Desired Ratio is not too large.  This enforces the
    // requirement that the bit rate is larger than requested.
    if((ui32SourceClock / ui32DesiredRatio) > ui32BitRate)
    {
        ui32DesiredRatio += 1;
    }

    // Check all possible values to find a matching value.
    while(ui32DesiredRatio <= CAN_MAX_PRE_DIVISOR * CAN_MAX_BIT_DIVISOR)
    {
        // Loop through all possible CAN bit divisors.
        for(ui32CANBits = CAN_MAX_BIT_DIVISOR;
            ui32CANBits >= CAN_MIN_BIT_DIVISOR;
            ui32CANBits--)
        {
            // For a given CAN bit divisor save the pre divisor.
            ui32PreDivide = ui32DesiredRatio / ui32CANBits;

            // If the calculated divisors match the desired clock ratio then
            // return these bit rate and set the CAN bit timing.
            if((ui32PreDivide * ui32CANBits) == ui32DesiredRatio)
            {
                // Start building the bit timing value by adding the bit timing
                // in time quanta.
                ui32RegValue =
                    g_ui16CANBitValues[ui32CANBits - CAN_MIN_BIT_DIVISOR];

                // To set the bit timing register, the controller must be
                // placed
                // in init mode (if not already), and also configuration change
                // bit enabled.  The state of the register should be saved
                // so it can be restored.

                ui16CANCTL = HWREGH(ui32Base + CAN_O_CTL);
                HWREGH(ui32Base + CAN_O_CTL) = ui16CANCTL | CAN_CTL_INIT |
                                               CAN_CTL_CCE;

                // Now add in the pre-scalar on the bit rate.
                ui32RegValue |= ((ui32PreDivide - 1) & CAN_BTR_BRP_M) |
                				(((ui32PreDivide - 1) << 10) & CAN_BTR_BRPE_M);

                // Set the clock bits in the and the bits of the
                // pre-scalar.
                HWREGH(ui32Base + CAN_O_BTR) = (ui32RegValue &
                                                CAN_REG_WORD_MASK);
                HWREGH(ui32Base + CAN_O_BTR + 2) = (ui32RegValue >> 16);

                // Restore the saved CAN Control register.
                HWREGH(ui32Base + CAN_O_CTL) = ui16CANCTL;

                // Return the computed bit rate.
                return(ui32SourceClock / ( ui32PreDivide * ui32CANBits));
            }
        }

        // Move the divisor up one and look again.  Only in rare cases are
        // more than 2 loops required to find the value.
        ui32DesiredRatio++;
    }
    return(0);
}
void
CANIntEnable(uint32_t ui32Base, uint32_t ui32IntFlags)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntFlags & ~(CAN_INT_ERROR | CAN_INT_STATUS | CAN_INT_IE0 |
                             CAN_INT_IE1)) == 0);

    // Enable the specified interrupts.
    HWREGH(ui32Base + CAN_O_CTL) = (HWREGH(ui32Base + CAN_O_CTL) |
                                    (ui32IntFlags & CAN_REG_WORD_MASK));

    HWREGH(ui32Base + CAN_O_CTL + 2) = (HWREGH(ui32Base + CAN_O_CTL + 2) |
                                        (ui32IntFlags >> 16));
}
CANIntDisable(uint32_t ui32Base, uint32_t ui32IntFlags)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntFlags & ~(CAN_INT_ERROR | CAN_INT_STATUS | CAN_INT_IE0 |
                             CAN_INT_IE1)) == 0);

    // Disable the specified interrupts.
    HWREGH(ui32Base + CAN_O_CTL) = HWREGH(ui32Base + CAN_O_CTL) &
                                  ~(ui32IntFlags & CAN_REG_WORD_MASK);

    HWREGH(ui32Base + CAN_O_CTL + 2) = HWREGH(ui32Base + CAN_O_CTL + 2) &
                                       ~(ui32IntFlags >> 16);
}
void
CANMessageGet(uint32_t ui32Base, uint32_t ui32ObjID, tCANMsgObject *pMsgObject,
              bool bClrPendingInt)
{
    uint32_t ui32CmdMaskReg;
    uint32_t ui32MaskReg;
    uint32_t ui32ArbReg;
    uint32_t ui32MsgCtrl;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32ObjID <= 32) && (ui32ObjID != 0));

    // This is always a read to the Message object as this call is setting a
    // message object.
    ui32CmdMaskReg = (CAN_IF2CMD_DATA_A | CAN_IF2CMD_DATA_B |
                      CAN_IF2CMD_CONTROL | CAN_IF2CMD_MASK | CAN_IF2CMD_ARB);

    // Clear a pending interrupt and new data in a message object.
    if(bClrPendingInt)
    {
        ui32CmdMaskReg |= CAN_IF2CMD_CLRINTPND | CAN_IF2CMD_TXRQST;
    }

    // Set up the request for data from the message object.
    HWREGH(ui32Base + CAN_O_IF2CMD + 2) =  ui32CmdMaskReg >> 16;

    // Transfer the message object to the message object specified by ui32ObjID.
    HWREGH(ui32Base + CAN_O_IF2CMD) = ui32ObjID & CAN_IF2CMD_MSG_NUM_M;

    // Wait for busy bit to clear
    while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
    {
    }

    // Read out the IF Registers.
    ui32MaskReg = HWREG(ui32Base + CAN_O_IF2MSK);
    ui32ArbReg = HWREG(ui32Base + CAN_O_IF2ARB);
    ui32MsgCtrl = HWREG(ui32Base + CAN_O_IF2MCTL);
    pMsgObject->ui32Flags = MSG_OBJ_NO_FLAGS;

    // Determine if this is a remote frame by checking the TXRQST and DIR bits.
    if((!(ui32MsgCtrl & CAN_IF2MCTL_TXRQST) && (ui32ArbReg & CAN_IF2ARB_DIR)) ||
       ((ui32MsgCtrl & CAN_IF2MCTL_TXRQST) && (!(ui32ArbReg & CAN_IF2ARB_DIR))))
    {
        pMsgObject->ui32Flags |= MSG_OBJ_REMOTE_FRAME;
    }

    // Get the identifier out of the register, the format depends on size of
    // the mask.
    if(ui32ArbReg & CAN_IF2ARB_XTD)
    {
        // Set the 29 bit version of the Identifier for this message object.
        pMsgObject->ui32MsgID = ui32ArbReg & CAN_IF2ARB_ID_M;

        pMsgObject->ui32Flags |= MSG_OBJ_EXTENDED_ID;
    }
    else
    {
        // The Identifier is an 11 bit value.
        pMsgObject->ui32MsgID = (ui32ArbReg &
                                 CAN_IF2ARB_STD_ID_M) >> CAN_IF2ARB_STD_ID_S;
    }

    // Indicate that we lost some data.
    if(ui32MsgCtrl & CAN_IF2MCTL_MSGLST)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_DATA_LOST;
    }

    // Set the flag to indicate if ID masking was used.
    if(ui32MsgCtrl & CAN_IF2MCTL_UMASK)
    {
        if(ui32ArbReg & CAN_IF2ARB_XTD)
        {
            // The Identifier Mask is assumed to also be a 29 bit value.
            pMsgObject->ui32MsgIDMask = (ui32MaskReg & CAN_IF2MSK_MSK_M);

            // If this is a fully specified Mask and a remote frame then don't
            // set the MSG_OBJ_USE_ID_FILTER because the ID was not really
            // filtered.
            if((pMsgObject->ui32MsgIDMask != 0x1fffffff) ||
               ((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0))
            {
                pMsgObject->ui32Flags |= MSG_OBJ_USE_ID_FILTER;
            }
        }
        else
        {
            // The Identifier Mask is assumed to also be an 11 bit value.
            pMsgObject->ui32MsgIDMask = ((ui32MaskReg & CAN_IF2MSK_MSK_M) >>
                                         18);

            // If this is a fully specified Mask and a remote frame then don't
            // set the MSG_OBJ_USE_ID_FILTER because the ID was not really
            // filtered.
            if((pMsgObject->ui32MsgIDMask != 0x7ff) ||
               ((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0))
            {
                pMsgObject->ui32Flags |= MSG_OBJ_USE_ID_FILTER;
            }
        }

        // Indicate if the extended bit was used in filtering.
        if(ui32MaskReg & CAN_IF2MSK_MXTD)
        {
            pMsgObject->ui32Flags |= MSG_OBJ_USE_EXT_FILTER;
        }

        // Indicate if direction filtering was enabled.
        if(ui32MaskReg & CAN_IF2MSK_MDIR)
        {
            pMsgObject->ui32Flags |= MSG_OBJ_USE_DIR_FILTER;
        }
    }

    // Set the interrupt flags.
    if(ui32MsgCtrl & CAN_IF2MCTL_TXIE)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_TX_INT_ENABLE;
    }
    if(ui32MsgCtrl & CAN_IF2MCTL_RXIE)
    {
        pMsgObject->ui32Flags |= MSG_OBJ_RX_INT_ENABLE;
    }

    // See if there is new data available.
    if(ui32MsgCtrl & CAN_IF2MCTL_NEWDAT)
    {
        // Get the amount of data needed to be read.
        pMsgObject->ui32MsgLen = (ui32MsgCtrl & CAN_IF2MCTL_DLC_M);

        // Don't read any data for a remote frame, there is nothing valid in
        // that buffer anyway.
        if((pMsgObject->ui32Flags & MSG_OBJ_REMOTE_FRAME) == 0)
        {
            // Read out the data from the CAN registers.
            CANDataRegRead(pMsgObject->pucMsgData,
                           (uint32_t *)(ui32Base + CAN_O_IF2DATA),
                           pMsgObject->ui32MsgLen);
        }

        // Now clear out the new data flag.
        HWREGH(ui32Base + CAN_O_IF2CMD + 2) = CAN_IF2CMD_TXRQST >> 16;

        // Transfer the message object to the message object specified by
        // ui32ObjID.
        HWREGH(ui32Base + CAN_O_IF2CMD) = ui32ObjID & CAN_IF2CMD_MSG_NUM_M;

        // Wait for busy bit to clear
        while(HWREGH(ui32Base + CAN_O_IF2CMD) & CAN_IF2CMD_BUSY)
        {
        }

        // Indicate that there is new data in this message.
        pMsgObject->ui32Flags |= MSG_OBJ_NEW_DATA;
    }
    else
    {
        // Along with the MSG_OBJ_NEW_DATA not being set the amount of data
        // needs to be set to zero if none was available.
        pMsgObject->ui32MsgLen = 0;
    }
}
uint32_t
CANIntStatus(uint32_t ui32Base, tCANIntStsReg eIntStsReg)
{
    uint32_t ui32Status;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // See which status the caller is looking for.
    switch(eIntStsReg)
    {
        // The caller wants the global interrupt status for the CAN controller
        // specified by ui32Base.
        case CAN_INT_STS_CAUSE:
        {
            ui32Status = HWREG(ui32Base + CAN_O_INT);
            break;
        }

        // The caller wants the current message status interrupt for all
        // messages.
        case CAN_INT_STS_OBJECT:
        {
            // Read message object interrupt status
            ui32Status = HWREG(ui32Base + CAN_O_IPEN_21);
            break;
        }

        // Request was for unknown status so just return 0.
        default:
        {
            ui32Status = 0;
            break;
        }
    }
    // Return the interrupt status value
    return(ui32Status);
}
uint32_t
CANStatusGet(uint32_t ui32Base, tCANStsReg eStatusReg)
{
    uint32_t ui32Status;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    switch(eStatusReg)
    {
        // Just return the global CAN status register since that is what was
        // requested.
        case CAN_STS_CONTROL:
        {
            ui32Status = HWREG(ui32Base + CAN_O_ES);
            break;
        }

        // Return objects with valid transmit requests
        case CAN_STS_TXREQUEST:
        {
            ui32Status = HWREG(ui32Base + CAN_O_TXRQ_21);
            break;
        }

        // Return messages objects with new data
        case CAN_STS_NEWDAT:
        {
            ui32Status = HWREG(ui32Base + CAN_O_NDAT_21);
            break;
        }

        // Return valid message objects
        case CAN_STS_MSGVAL:
        {
            ui32Status = HWREG(ui32Base + CAN_O_MVAL_21);
            break;
        }

        // Unknown CAN status requested so return 0.
        default:
        {
            ui32Status = 0;
            break;
        }
    }
    return(ui32Status);
}
void
CANGlobalIntEnable(uint32_t ui32Base, uint32_t ui32IntFlags)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntFlags & ~(CAN_GLB_INT_CANINT0 |
                             CAN_GLB_INT_CANINT1)) == 0);

    //enable the requested interrupts
    HWREGH(ui32Base + CAN_O_GLB_INT_EN) |= ui32IntFlags;
}
void
CANIntClear(uint32_t ui32Base, uint32_t ui32IntClr)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntClr == CAN_INT_INT0ID_STATUS) ||
           ((ui32IntClr>=1) && (ui32IntClr <=32)));

    if(ui32IntClr == CAN_INT_INT0ID_STATUS)
    {
        // Simply read and discard the status to clear the interrupt.
        HWREG(ui32Base + CAN_O_ES);
    }
    else
    {
        // Wait to be sure that this interface is not busy.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }

        // Only change the interrupt pending state by setting only the
        // CAN_IF1CMD_CLRINTPND bit.
        HWREGH(ui32Base + CAN_O_IF1CMD + 2) = CAN_IF1CMD_CLRINTPND >> 16;

        // Send the clear pending interrupt command to the CAN controller.
        HWREGH(ui32Base + CAN_O_IF1CMD) = ui32IntClr & CAN_IF1CMD_MSG_NUM_M;

        // Wait to be sure that this interface is not busy.
        while(HWREGH(ui32Base + CAN_O_IF1CMD) & CAN_IF1CMD_BUSY)
        {
        }
    }
}
void
CANGlobalIntClear(uint32_t ui32Base, uint32_t ui32IntFlags)
{
    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));
    ASSERT((ui32IntFlags & ~(CAN_GLB_INT_CANINT0 |
                             CAN_GLB_INT_CANINT1)) == 0);

    //clear the requested interrupts
    HWREGH(ui32Base + CAN_O_GLB_INT_CLR) = ui32IntFlags;
}
static int32_t
CANIntNumberGet(uint32_t ui32Base, unsigned char ucNumber)
{
    int32_t lIntNumber;

    // Return the interrupt number for the given CAN controller.
    switch(ui32Base)
    {
        // Return the interrupt number for CAN 0
        case CANA_BASE:
        {
            switch(ucNumber)
            {
            case 0:
            {
                lIntNumber = INT_CANA_0;
                break;
            }
            case 1:
            {
                lIntNumber = INT_CANA_1;
                break;

            }
            default:
            {
                lIntNumber = -1;
                break;
            }
            }
            break;
        }

        // Return the interrupt number for CAN 1
        case CANB_BASE:
        {
            switch(ucNumber)
            {
            case 0:
            {
                lIntNumber = INT_CANB_0;
                break;
            }
            case 1:
            {
                lIntNumber = INT_CANB_1;
                break;

            }
            default:
            {
                lIntNumber = -1;
                break;
            }
            }
            break;
        }

        // Return -1 to indicate a bad address was passed in.
        default:
        {
            lIntNumber = -1;
        }
    }
    return(lIntNumber);
}
void
CANIntRegister(uint32_t ui32Base, unsigned char ucIntNumber,
               void (*pfnHandler)(void))
{
    uint32_t ui32IntNumber;

    // Check the arguments.
    ASSERT(CANBaseValid(ui32Base));

    // Get the actual interrupt number for this CAN controller.
    ui32IntNumber = CANIntNumberGet(ui32Base, ucIntNumber);

    // Register the interrupt handler.
    IntRegister(ui32IntNumber, pfnHandler);

    // Enable the CAN interrupt.
    IntEnable(ui32IntNumber);
}
void
IntEnable(uint32_t ui32Interrupt)
{
    uint16_t ui16IntsEnabled;

    ui32Interrupt = ui32Interrupt >> 16;
    EALLOW;
    //Ensure that PIE is enabled
    PieCtrlRegs.PIECTRL.bit.ENPIE=1;

    ui16IntsEnabled = IntMasterDisable();

    if (ui32Interrupt >= 0x20 && ui32Interrupt <= 0x7F) //Lower PIE table
    {
        //Enable Individual PIE interrupt
        *(uint16_t *)((&PieCtrlRegs.PIEIER1.all) + (((ui32Interrupt-0x20)/8))*2) |= 1 << ((ui32Interrupt-0x20)%8);

        // Wait for any pending interrupts to get to the CPU
        asm(" nop");
        asm(" nop");
        asm(" nop");
        asm(" nop");
        asm(" nop");

        //Clear the CPU flag
        IntIFRClear(1 << ((ui32Interrupt - 0x20)/8));

        //Acknowlege any interrupts
        PieCtrlRegs.PIEACK.all = 1 << ((ui32Interrupt - 0x20)/8);

        //Enable PIE Group Interrupt
        IER |= 1 << ((ui32Interrupt - 0x20)/8);
    }
    else if (ui32Interrupt >= 0x80) //Upper PIE table
    {
        //Enable Individual PIE interrupt
        *(uint16_t *)((&PieCtrlRegs.PIEIER1.all) + (((ui32Interrupt-0x80)/8))*2) |= 1 << (((ui32Interrupt-0x80)%8)+8);

        // Wait for any pending interrupts to get to the CPU
        asm(" nop");
        asm(" nop");
        asm(" nop");
        asm(" nop");
        asm(" nop");

        //Clear the CPU flag
        IntIFRClear(1 << ((ui32Interrupt - 0x80)/8));

        //Acknowlege any interrupts
        PieCtrlRegs.PIEACK.all = 1 << ((ui32Interrupt - 0x80)/8);

        //Enable PIE Group Interrupt
        IER |= 1 << ((ui32Interrupt - 0x80)/8);
    }
    else if (ui32Interrupt >= 0x0D && ui32Interrupt <= 0x10) //INT13, INT14, DLOGINT, & RTOSINT
    {
        //Enable PIE Group Interrupt
        IER |= 1 << (ui32Interrupt - 1);
    }
    else
    {
        //Other interrupts
    }

    EDIS;

    //Re-enable interrupts if they were enabled
    if(!ui16IntsEnabled){
        IntMasterEnable();
    }
}
void
IntRegister(uint32_t ui32Interrupt, void (*pfnHandler)(void))
{
    EALLOW;
    //Copy ISR address into PIE table
    memcpy((uint16_t *) &PieVectTable + ((ui32Interrupt & 0xFFFF0000) >> 16)*2, (uint16_t *) &pfnHandler, sizeof(pfnHandler));
    EDIS;
}
bool
IntMasterEnable(void)
{
    //
    // Enable processor interrupts.
    //
    return __enable_interrupts() & 0x1;
}
bool
IntMasterDisable(void)
{
    //
    // Disable processor interrupts.
    //
    return __disable_interrupts() & 0x1;
}
void IntIFRClear(uint16_t ui16Interrupts)
{
    switch(ui16Interrupts){
    case 0x0001:
        IFR &= ~0x0001;
        break;
    case 0x0002:
        IFR &= ~0x0002;
        break;
    case 0x0004:
        IFR &= ~0x0004;
        break;
    case 0x0008:
        IFR &= ~0x0008;
        break;
    case 0x0010:
        IFR &= ~0x0010;
        break;
    case 0x0020:
        IFR &= ~0x0020;
        break;
    case 0x0040:
        IFR &= ~0x0040;
        break;
    case 0x0080:
        IFR &= ~0x0080;
        break;
    case 0x0100:
        IFR &= ~0x0100;
        break;
    case 0x0200:
        IFR &= ~0x0200;
        break;
    case 0x0400:
        IFR &= ~0x0400;
        break;
    case 0x0800:
        IFR &= ~0x0800;
        break;
    case 0x1000:
        IFR &= ~0x1000;
        break;
    case 0x2000:
        IFR &= ~0x2000;
        break;
    case 0x4000:
        IFR &= ~0x4000;
        break;
    case 0x8000:
        IFR &= ~0x8000;
        break;
    default:
        break;
    }
}
*/
// User Code End!!! -->
