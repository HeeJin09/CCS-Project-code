//#############################################################################
// FILE:   main.c
//
// TITLE:  Main
//
// Modification from Empty Bit-Field & Driverlib Example by rnr
//
// This example is an empty project setup for Bit-Field and Driverlib development.
//
//#############################################################################
// $TI Release: F2837xS Support Library v3.03.00.00 $
// $Release Date: Thu Dec  7 18:53:06 CST 2017 $
// $Copyright:
// Copyright (C) 2014-2017 Texas Instruments Incorporated - http://www.ti.com/
// 
//#############################################################################
// Compiler ver.15.12.5.LTS

//Includes files---------------------------------------------------------------
#include "F28x_Project.h"
#include "device.h"

#include "easydsp\easy2837xS_sci_v8.5.h"
#include "easydsp\RingBuff.h"

#include "variables.h"
#include "cc.h"
#include "CANlibrary.h"

//Define -------------------------------------------------------------------
#define CHANNEL_NUM  4
#define WINDOW_SIZE  200

//Function ------------------------------------------------------------------
void Intan_Init(void);

uint16_t SendReadCommand(uint8_t reg);
void SendWriteCommand(uint8_t reg, uint8_t value);

uint16_t SendConvertCommand(uint8_t channelnum);
uint16_t SendConvertCommandH(uint8_t channelnum);

void Calibrate(void);
int smoothing(int channel);

//Variables -------------------------------------------------------------------
float babo = 0;
unsigned int babo2 = 0;
unsigned int SetLed = 0;
unsigned int gpbData = 0;

unsigned int GD1_enable = 0, GD2_enable = 0, GD3_enable = 0, GD4_enable = 0;
unsigned long u32CntTXMsgData = 0x12345678;

tCANMsgObject sTXCANMessage;
tCANMsgObject sRXCANMessage;

Uint16 spi_sdata;
Uint16 spi_rdata;

//EMG -------------------------------------------------------------------------
int THRESHOLD = 40;
int emgdata[4] = {0,0,0,0};
int filterdata[4] = {0,0,0,0};
uint16_t channel_data[4] = {0,0,0,0};

uint16_t spi2_rxBuffer;
uint16_t spi2_txBuffer;

int pat_num = 0;

int readings[WINDOW_SIZE];
int WINDOW_INDEX = 0;
int total = 0;
int average = 0;

//Main ------------------------------------------------------------------------
void main(void)
{
        InitSysCtrl();
        InitCpuTimers();

        InitGpio();
        InitAdc();
        InitTempSensor(3.3);

        InitEPwmGpio();
        InitEQep();
        InitEQepGpio();

        //InitSpibGpio();
        EALLOW;
        GPIO_setDirectionMode(58, GPIO_DIR_MODE_OUT);   // SPI-B-CLK (pin58) set as output
        GPIO_setDirectionMode(59, GPIO_DIR_MODE_OUT);   // SPI-B-CS (pin59) set as output
        GPIO_setDirectionMode(60, GPIO_DIR_MODE_OUT);   // SPI-B-MOSI (pin60) set as output
        GPIO_setDirectionMode(61, GPIO_DIR_MODE_IN);    // SPI-B-MISO (pin60) set as input
        GPIO_setPinConfig(GPIO_58_SPICLKB);
        GPIO_setPinConfig(GPIO_59_GPIO59);
        GPIO_setPinConfig(GPIO_60_SPISIMOB);
        GPIO_setPinConfig(GPIO_61_SPISOMIB);
        EDIS;

        CANInit(CANA_BASE);
        CANClkSourceSelect(CANA_BASE, 0);
        CANBitRateSet(CANA_BASE, 200000000, 500000);

        DINT;

        InitPieCtrl();

        IER = 0x0000;
        IFR = 0x0000;

        InitPieVectTable();

        // Map ISR functions
        EALLOW;
        PieVectTable.EPWM1_INT = &cc_isr;
        EDIS;

        easyDSP_SCI_Init();

        PieCtrlRegs.PIEIER3.bit.INTx1 = 1;

        IER |= M_INT3;
        EINT;

        //spi_A
        SPI_disableModule(SPIA_BASE);
        SPI_setConfig(SPIA_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL1PHA0, SPI_MODE_MASTER, 10000000, 16);
        SPI_enableLoopback(SPIA_BASE);
        SPI_setEmulationMode(SPIA_BASE, SPI_EMULATION_FREE_RUN);
        SPI_enableModule(SPIA_BASE);

        //spi_B
        SPI_disableModule(SPIB_BASE);
        SPI_setConfig(SPIB_BASE, DEVICE_LSPCLK_FREQ, SPI_PROT_POL1PHA0, SPI_MODE_MASTER, 10000000, 16);
        //SPI_enableLoopback(SPIB_BASE);
        //SPI_setEmulationMode(SPIB_BASE, SPI_EMULATION_FREE_RUN);
        SPI_enableModule(SPIB_BASE);

        // custom initiation
        daInit();
        InitFlags();
        Intan_Init();

        // <-- User Code Start!!!

        DATA_OBJECT dObj;

        unsigned char RXdata[8];
        unsigned char TXdata[8];

        //CANopen RX
        unsigned short can_id_receive = SDO_RXID_BASELINE + DEVICE_ID;      //RX ID

        CAN_PACKET packet_receive;
        memset(packet_receive.value, 0, sizeof(packet_receive.value));
        packet_receive.info.attrib = CAN_ATTRIBUTION_READ_1BYTE;
        // dObj.uint16Value[0] = INDEX_FORCECONTROL;
        packet_receive.info.index[0] = dObj.uint8Value[0];
        packet_receive.info.index[1] = dObj.uint8Value[1];
        packet_receive.info.subindex = 0x01;
        packet_receive.info.data[0] = 4;
        memcpy(RXdata, packet_receive.value, sizeof(packet_receive.value));
        
        //CANopen TX
        unsigned short can_id_transmit = SDO_TXID_BASELINE + DEVICE_ID;     //TX ID

        // CAN_PACKET packet_transmit;
        // memset(packet_transmit.value, 0, sizeof(packet_transmit.value));
        // packet_transmit.info.attrib = CAN_ATTRIBUTION_WRITE_1BYTE;
        // // dObj.uint16Value[0] = INDEX_FORCECONTROL;
        // packet_transmit.info.index[0] = index_tx[0];
        // packet_transmit.info.index[1] = index_tx[1];
        // packet_transmit.info.subindex = 0x1;
        // packet_transmit.info.data[0] = txd[0];
        // packet_transmit.info.data[1] = txd[1];
        // packet_transmit.info.data[2] = txd[2];
        // packet_transmit.info.data[3] = txd[3];
        // memcpy(TXdata, packet_transmit.value, sizeof(packet_transmit.value));

        // RXMsgData[0] = RXdata[4];
        // RXMsgData[1] = RXdata[5];
        // RXMsgData[2] = RXdata[6];
        // RXMsgData[3] = RXdata[7];

        //
        // Initialize the transmit message object used for sending CAN messages.
        // Message Object Parameters:
        //      Message Identifier: 0x5555
        //      Message ID Mask: 0x0
        //      Message Object Flags: None
        //      Message Data Length: 4 Bytes
        //      Message Transmit data: txMsgData
        //
        sTXCANMessage.ui32MsgID = 1;
        sTXCANMessage.ui32MsgIDMask = 0;
        sTXCANMessage.ui32Flags = 0;
        sTXCANMessage.ui32MsgLen = sizeof(TXMsgData);
        sTXCANMessage.pucMsgData = TXMsgData;

        sRXCANMessage.ui32MsgID = 111;
        sRXCANMessage.ui32MsgIDMask = 0;
        sRXCANMessage.ui32Flags = MSG_OBJ_RX_INT_ENABLE | MSG_OBJ_EXTENDED_ID | MSG_OBJ_USE_ID_FILTER;
        sRXCANMessage.ui32MsgLen = sizeof(RXMsgData);
        sRXCANMessage.pucMsgData = RXMsgData;

        CANMessageSet(CANA_BASE, 0, &sRXCANMessage, MSG_OBJ_TYPE_RX);
        
        // Start CAN module A and B operations
        CANEnable(CANA_BASE);


        // Gain initiation
        Tau = 0.01;
        Kd_pc = 2.36;
        Flag_pd=0;
        Kp_pc=1117.010742;
        Kd_pc=0;

        J=1.20000001e-008;
        Wc_sc=2*PI*50;  // Ori: 100
        Ki_sc_ratio=10;
        Ka_sc_ratio=1;
        Kad_sc=0.0000001;
        Wrmrated=900; // ori:588

        Wsf=2*PI*100;  // Ori: 200Hz
        zeta=1.414;

        Ls=0.000168;
        Rs=2;
        Wcc=2*PI*500; // Ori: 500Hz
        Irated=0.35;
        I_max=1;

    while(1)
    {
        int i;
        for (i = 0 ; i < CHANNEL_NUM; i++)
        {
            channel_data[i] = SendConvertCommand(i);
            emgdata[i] = (int)(channel_data[i] * 0.195);
            filterdata[i] = smoothing(emgdata[i]);
        }

        //Make a pattern
        if(filterdata[0]<THRESHOLD && filterdata[1]<THRESHOLD && filterdata[2]<THRESHOLD && filterdata[3]<THRESHOLD)
        {
            pat_num = 1;
        }

        if(filterdata[0]>=THRESHOLD && filterdata[1]>=THRESHOLD && filterdata[2]>=THRESHOLD && filterdata[3]>=THRESHOLD)
        {
            pat_num = 2;
        }
        if(filterdata[0]<THRESHOLD && filterdata[1]<THRESHOLD && filterdata[2]<THRESHOLD && filterdata[3]>=THRESHOLD)
        {
            pat_num = 3;
        }

        babo = babo + 1.;
        if(babo>10000)
        {

           //CpuTimer0Regs.TCR.bit.TSS = 1;
           babo2++;
           if(babo2>=10) {babo2 = 0;}
//            GpioDataRegs.GPACLEAR.bit.GPIO17 = 1;   // DAC_nLD low
              babo=0;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO48 = 1;
//            GpioDataRegs.GPBSET.bit.GPIO49 = 1;
//            GpioDataRegs.GPBSET.bit.GPIO50 = 1;
//            GpioDataRegs.GPBSET.bit.GPIO51 = 1;


//            GpioCtrlRegs.GPBMUX1.all = 0x0000;
//            GpioCtrlRegs.GPBDIR.all = (GpioCtrlRegs.GPBDIR.all&0x0000ffff)|0xfcfc0000;

             // Transmit Message
             CAN_PACKET packet_transmit;
             memset(packet_transmit.value, 0, sizeof(packet_transmit.value));
             packet_transmit.info.attrib = CAN_ATTRIBUTION_WRITE_1BYTE;
             //dObj.uint16Value[0] = INDEX_FORCECONTROL;
             index_tx[0] = 0x93;
             index_tx[1] = 0x60;

             packet_transmit.info.index[0] = index_tx[0];
             packet_transmit.info.index[1] = index_tx[1];
             packet_transmit.info.subindex = 0x1;
             packet_transmit.info.data[0] = txd[0];
             packet_transmit.info.data[1] = txd[1];
             packet_transmit.info.data[2] = txd[2];
             packet_transmit.info.data[3] = txd[3];
             memcpy(TXdata, packet_transmit.value, sizeof(packet_transmit.value));
            
             TXMsgData[0] = TXdata[0];
             TXMsgData[1] = TXdata[1];
             TXMsgData[2] = TXdata[2];
             TXMsgData[3] = TXdata[3];
             TXMsgData[4] = TXdata[4];
             TXMsgData[5] = TXdata[5];
             TXMsgData[6] = TXdata[6];
             TXMsgData[7] = TXdata[7];
            
//            GpioDataRegs.GPBTOGGLE.bit.GPIO48 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO49 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO50 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO51 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO52 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO53 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO54 = 1;
//            GpioDataRegs.GPBTOGGLE.bit.GPIO55 = 1;
//
//            TXMsgData[0] = GpioDataRegs.GPBDAT.bit.GPIO48;
//            TXMsgData[1] = GpioDataRegs.GPBDAT.bit.GPIO49;
//            TXMsgData[2] = GpioDataRegs.GPBDAT.bit.GPIO50;
//            TXMsgData[3] = GpioDataRegs.GPBDAT.bit.GPIO51;
//            TXMsgData[4] = GpioDataRegs.GPBDAT.bit.GPIO52;
//            TXMsgData[5] = GpioDataRegs.GPBDAT.bit.GPIO53;
//            TXMsgData[6] = GpioDataRegs.GPBDAT.bit.GPIO54;
//            TXMsgData[7] = GpioDataRegs.GPBDAT.bit.GPIO55;
            

            CANMessageGet(CANA_BASE, 0, &sRXCANMessage, true);

            CANMessageSet(CANA_BASE, 1, &sTXCANMessage, MSG_OBJ_TYPE_TX);
            CANMessageSet(CANA_BASE, 2, &sTXCANMessage, MSG_OBJ_TYPE_TX);

            CANIntClear(CANA_BASE, 0);

            EALLOW;
            HWREG(CANA_BASE + CAN_O_CTL) = 0;
            EDIS;
        }
    }

}

// SPI  ------------------------------------------------------------------------
void SendWriteCommand(uint8_t reg, uint8_t value)
{
    uint8_t myTx[2];
    uint16_t tx_data;

    myTx[1] = reg | 0x80;
    myTx[0] = value;

    tx_data = myTx[1]<<8 | myTx[0];

    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 1;   //spi2 cs low
    DELAY_US(1);
    SPI_writeDataNonBlocking(SPIB_BASE, tx_data);
    DELAY_US(1);
    spi2_rxBuffer=SPI_readDataBlockingNonFIFO(SPIB_BASE);
    DELAY_US(1);
    GpioDataRegs.GPBSET.bit.GPIO59 = 1; // spi2 cs high
}

uint16_t SendReadCommand(uint8_t reg)
{
    uint16_t rx_data;

    uint16_t mask = reg << 8;
    mask = 0xc000 | mask;

    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 1;   //spi2 cs low
    DELAY_US(1);
    SPI_writeDataNonBlocking(SPIB_BASE, mask);
    DELAY_US(1);
    rx_data=SPI_readDataNonBlocking(SPIB_BASE);
    DELAY_US(1);
    GpioDataRegs.GPBSET.bit.GPIO59 = 1; // spi2 cs high

    return rx_data;
}

uint16_t SendConvertCommand(uint8_t channelnum)
{
    uint16_t rx_data;

    uint16_t mask = channelnum << 8;
    mask = 0x0000 | mask;

    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 1;   //spi2 cs low
    DELAY_US(1);
    SPI_writeDataNonBlocking(SPIB_BASE, mask);
    DELAY_US(1);
    rx_data=SPI_readDataNonBlocking(SPIB_BASE);
    DELAY_US(1);
    GpioDataRegs.GPBSET.bit.GPIO59 = 1; // spi2 cs high

    return rx_data;
}

uint16_t SendConvertCommandH(uint8_t channelnum)
{
    uint16_t rx_data;

    uint16_t mask = channelnum << 8;
    mask = 0x0001 | mask;

    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 1;   //spi2 cs low
    DELAY_US(1);
    SPI_writeDataNonBlocking(SPIB_BASE, mask);
    DELAY_US(1);
    rx_data=SPI_readDataNonBlocking(SPIB_BASE);
    DELAY_US(1);
    GpioDataRegs.GPBSET.bit.GPIO59 = 1; // spi2 cs high

    return rx_data;
}


void Calibrate(void)
{
    uint16_t tx_data = 0x5500;
    uint16_t rx_data;

    GpioDataRegs.GPBCLEAR.bit.GPIO59 = 1;   //spi2 cs low
    DELAY_US(1);
    SPI_writeDataNonBlocking(SPIB_BASE, tx_data);
    DELAY_US(1);
    rx_data=SPI_readDataNonBlocking(SPIB_BASE);
    DELAY_US(1);
    GpioDataRegs.GPBSET.bit.GPIO59 = 1;

    int i = 0;
    for (i = 0; i < 9; i++)
    {
        //Use the READ command as a dummy command that acts only to set the 9 clock cycles the calibration needs to complete
        SendReadCommand(40);
    }
}

void Intan_Init(void)
{
  SendWriteCommand(0x00, 0xDE); //1111 1110
  SendWriteCommand(0x01, 0x60); //0110 0000
  SendWriteCommand(0x02, 40);
  SendWriteCommand(0x03, 0x00);
  SendWriteCommand(0x04, 0xF6);
  SendWriteCommand(0X05, 0x00);
  SendWriteCommand(0X06, 0x00);
  SendWriteCommand(0X07, 0x00);

  SendWriteCommand(8, 46);
  SendWriteCommand(9, 2);
  SendWriteCommand(10, 30);
  SendWriteCommand(11, 3);

  uint8_t R12, RL, RLDAC1, R13, ADCaux3en, RLDAC3, RLDAC2;

  //R12
  RL = 0;
  RLDAC1 = 8;
  //R13
  ADCaux3en = 0;
  RLDAC3 = 0;
  RLDAC2 = 3;

  R12 = ((RL << 7) | RLDAC1);
  R13 = (ADCaux3en << 7) | (RLDAC3 << 6) | RLDAC2;

  SendWriteCommand(12, R12);
  SendWriteCommand(13, R13);

  SendWriteCommand(14, 15); //CH
  SendWriteCommand(15, 0);
  SendWriteCommand(16, 0);
  SendWriteCommand(17, 0);

  Calibrate();
}

int smoothing(int channel)
{
    total = total - readings[WINDOW_INDEX];
    readings[WINDOW_INDEX] = channel;
    total = total + readings[WINDOW_INDEX];
    WINDOW_INDEX ++;

    if(WINDOW_INDEX >= WINDOW_SIZE)
    {
        WINDOW_INDEX = 0;
    }

    average = total / WINDOW_SIZE;

    return average;
}
