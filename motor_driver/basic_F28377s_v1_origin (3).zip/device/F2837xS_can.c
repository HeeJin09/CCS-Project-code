//###########################################################################
//
// FILE:   F2837xS_can.c
//
// TITLE:  F2837xS CAN Support Functions.
//
//###########################################################################
// $TI Release: F2837xS Support Library v210 $
// $Release Date: Tue Nov  1 15:35:23 CDT 2016 $
// $Copyright: Copyright (C) 2014-2016 Texas Instruments Incorporated -
//             http://www.ti.com/ ALL RIGHTS RESERVED $
//###########################################################################

//
// Included Files
//
#include "F2837xS_device.h"
#include "F2837xS_Examples.h"


//
// InitCAN - Initializes the CAN-A controller after reset.
//
void InitCAN(void)
{
    InitCANa();
}


void InitCANa(void)
{
	int16_t iMsg;
////////////////////////////////////////////////////////////////////////////////////////////////
    CanaRegs.CAN_CTL.bit.Init = 0;
	// CanaRegs.CAN_CTL.bit.SWR = 1;
    // CanaRegs.CAN_CTL.bit.ABO = 1;
    // CanaRegs.CAN_CTL.bit.DAR = 1;

    // CanaRegs.CAN_CTL.bit.Test = 1;
    // CanaRegs.CAN_TEST.bit.RX = 0;
    // CanaRegs.CAN_TEST.bit.TX = 11;
    // CanaRegs.CAN_TEST.bit.LBACK = 0;
    // CanaRegs.CAN_TEST.bit.SILENT = 0;
    // CanaRegs.CAN_TEST.bit.EXL = 1;


	//
    // Wait for busy bit to clear
	//
    while(CanaRegs.CAN_IF1CMD.bit.Busy)
    {
    }

    //
    // Clear the message value bit in the arbitration register.  This indicates
    // the message is not valid and is a "safe" condition to leave the message
    // object.  The same arb reg is used to program all the message objects.
    //
    CanaRegs.CAN_IF1CMD.bit.DIR = 1;
    CanaRegs.CAN_IF1CMD.bit.Arb = 1;
    CanaRegs.CAN_IF1CMD.bit.Control = 1;

    CanaRegs.CAN_IF1ARB.all = 0;

    CanaRegs.CAN_IF1MCTL.all = 0;

    CanaRegs.CAN_IF2CMD.bit.DIR = 1;
    CanaRegs.CAN_IF2CMD.bit.Arb = 1;
    CanaRegs.CAN_IF2CMD.bit.Control = 1;

    CanaRegs.CAN_IF2ARB.all = 0;

    CanaRegs.CAN_IF2MCTL.all = 0;

    //
    // Loop through to program all 32 message objects
    //
    for(iMsg = 1; iMsg <= 32; iMsg+=2)
    {
        //
    	// Wait for busy bit to clear
    	//
        while(CanaRegs.CAN_IF1CMD.bit.Busy)
        {
        }

        //
        // Initiate programming the message object
        //
        CanaRegs.CAN_IF1CMD.bit.MSG_NUM = iMsg;

        //
        // Wait for busy bit to clear
        //
        while(CanaRegs.CAN_IF2CMD.bit.Busy)
        {
        }

        //
        // Initiate programming the message object
        //
        CanaRegs.CAN_IF2CMD.bit.MSG_NUM = iMsg + 1;
    }

    //
    // Acknowledge any pending status interrupts.
    //
    volatile uint32_t discardRead = CanaRegs.CAN_ES.all;
///////////////////////////////////////////////////////////////////////////////////////////

	//
    // Place CAN controller in init state, regardless of previous state.  This
    // will put controller in idle, and allow the message object RAM to be
    // programmed.
	//

	// CanaRegs.CAN_CTL.bit.Init = 1;
	// CanaRegs.CAN_CTL.bit.SWR = 0;       //Enable software reset = 1, Normal operation = 0

    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // // CanaRegs.CAN_CTL.bit.ABO = 1;       //Enable auto-bus
    // // CanaRegs.CAN_CTL.bit.DAR = 0;       //Enable Automatic retransmission
    // CanaRegs.CAN_CTL.bit.Test = 1;      //Enable test mode


    // // CanaRegs.CAN_RAM_INIT.bit.CAN_RAM_INIT = 0;
    // // CanaRegs.CAN_RAM_INIT.bit.RAM_INIT_DONE = 1;
    // // CanaRegs.CAN_RAM_INIT.bit.KEY3 = 1010;
    // // CanaRegs.CAN_RAM_INIT.bit.KEY2 = 1010;
    // // CanaRegs.CAN_RAM_INIT.bit.KEY1 = 1010;
    // // CanaRegs.CAN_RAM_INIT.bit.KEY0 = 1010;

    // CanaRegs.CAN_TEST.bit.EXL = 1;      //Enable External loop back mode
    // // CanaRegs.CAN_TEST.bit.LBACK = 1;    //Enable loop back mode
    // // CanaRegs.CAN_TEST.bit.SILENT = 0;   //disable silent mode
    // // CanaRegs.CAN_TEST.bit.RX = 0;       //CAN bus is dominant = 0, recessive = 1
    // // CanaRegs.CAN_TEST.bit.TX = 10;      //CAN bus is dominant = 10, recessive = 11, Normal operation controlled by CAN core = 00, Sample point can monitores at CANTX pin = 01

    // // CanaRegs.CAN_BTR.bit.BRPE = 0;      //Baud rate Prescaler extension 0~15
    // // CanaRegs.CAN_BTR.bit.TSEG1 = 0;     //Time segment1 1~15
    // // CanaRegs.CAN_BTR.bit.TSEG2 = 0;     //Time segment2 0~7

    // ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



	// //
    // // Wait for busy bit to clear
	// //
    // while(CanaRegs.CAN_IF1CMD.bit.Busy)
    // {
    // }
 
    // //
    // // Clear the message value bit in the arbitration register.  This indicates
    // // the message is not valid and is a "safe" condition to leave the message
    // // object.  The same arb reg is used to program all the message objects.
    // //
    // CanaRegs.CAN_IF1CMD.bit.DIR = 1;        //read = 0, write = 1
    // CanaRegs.CAN_IF1CMD.bit.Mask = 0;
    // CanaRegs.CAN_IF1CMD.bit.Arb = 0;
    // CanaRegs.CAN_IF1CMD.bit.Control = 0;
    // CanaRegs.CAN_IF1CMD.bit.ClrIntPnd = 0;
    // CanaRegs.CAN_IF1CMD.bit.TXRQST = 1;
    // CanaRegs.CAN_IF1CMD.bit.DATA_A = 1;
    // CanaRegs.CAN_IF1CMD.bit.DATA_B = 1;

    // // CanaRegs.CAN_IF1ARB.all = 0;
    // CanaRegs.CAN_IF1ARB.bit.MsgVal = 1;
    // CanaRegs.CAN_IF1ARB.bit.Xtd = 0;            //11bit
    // CanaRegs.CAN_IF1ARB.bit.Dir = 1;            //transmit
    // CanaRegs.CAN_IF1ARB.bit.ID = 0x0002;

    // // CanaRegs.CAN_IF1MCTL.all = 0;
    // CanaRegs.CAN_IF1MCTL.bit.NewDat = 0;
    // CanaRegs.CAN_IF1MCTL.bit.IntPnd = 0;
    // CanaRegs.CAN_IF1MCTL.bit.TxIE = 1;
    // CanaRegs.CAN_IF1MCTL.bit.EoB = 1;

    // CanaRegs.CAN_IF2CMD.bit.DIR = 0;        //read = 0, write = 1
    // CanaRegs.CAN_IF2CMD.bit.Mask = 0;
    // CanaRegs.CAN_IF2CMD.bit.Arb = 0;
    // CanaRegs.CAN_IF2CMD.bit.Control = 0;
    // CanaRegs.CAN_IF2CMD.bit.ClrIntPnd = 0;
    // CanaRegs.CAN_IF2CMD.bit.TxRqst = 1;
    // CanaRegs.CAN_IF2CMD.bit.DATA_A = 1;
    // CanaRegs.CAN_IF2CMD.bit.DATA_B = 1;


    // // CanaRegs.CAN_IF2ARB.all = 0;
    // CanaRegs.CAN_IF2ARB.bit.MsgVal = 1;
    // CanaRegs.CAN_IF2ARB.bit.Xtd = 0;            //11bit
    // CanaRegs.CAN_IF2ARB.bit.Dir = 0;            //receive
    // CanaRegs.CAN_IF2ARB.bit.ID = 0x0002;


    // // CanaRegs.CAN_IF2MCTL.all = 0;
    // CanaRegs.CAN_IF2MCTL.bit.NewDat = 0;
    // CanaRegs.CAN_IF2MCTL.bit.IntPnd = 1;
    // CanaRegs.CAN_IF2MCTL.bit.TxIE = 1;
    // CanaRegs.CAN_IF2MCTL.bit.EoB = 1;

    // // CanaRegs.CAN_GLB_INT_EN.bit.GLBINT0_EN = 1;
    // // CanaRegs.CAN_GLB_INT_EN.bit.GLBINT1_EN = 1;


    // // CanaRegs.CAN_IF3OBS.bit.Data_A = 1;
    // // CanaRegs.CAN_IF3OBS.bit.IF3SDA = 1;

    // //
    // // Loop through to program all 32 message objects
    // //
    // for(iMsg = 1; iMsg <= 32; iMsg+=2)
    // {
    //     //
    // 	// Wait for busy bit to clear
    // 	//
    //     while(CanaRegs.CAN_IF1CMD.bit.Busy)
    //     {
    //     }

    //     //
    //     // Initiate programming the message object
    //     //
    //     CanaRegs.CAN_IF1CMD.bit.MSG_NUM = iMsg;     //0x01-0x20 Valid message numbers, 0x21-0xFF Invalid message numbers

    //     //
    //     // Wait for busy bit to clear
    //     //
    //     while(CanaRegs.CAN_IF2CMD.bit.Busy)
    //     {
    //     }

    //     //
    //     // Initiate programming the message object
    //     //
    //     CanaRegs.CAN_IF2CMD.bit.MSG_NUM = iMsg + 1;
    // }

    // //
    // // Acknowledge any pending status interrupts.
    // //
    // volatile uint32_t discardRead = CanaRegs.CAN_ES.all;

}

//
// End of file
//
