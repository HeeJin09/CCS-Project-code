//###########################################################################
//
// FILE:    F2837xS_Gpio.c
//
// TITLE:    GPIO module support functions
//
//###########################################################################
// $TI Release: F2837xS Support Library v3.03.00.00 $
// $Release Date: Thu Dec  7 18:53:06 CST 2017 $
// $Copyright:
// Copyright (C) 2014-2017 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//
// Included Files
//
#include "F2837xS_device.h"
#include "F2837xS_Examples.h"

//
// InitGpio - Sets all pins to be muxed to GPIO in input mode with pull-ups
//            enabled. Also disables open drain and polarity inversion and sets
//            the qualification to synchronous. Also unlocks all GPIOs
//
void InitGpio()
{
    volatile Uint32 *gpioBaseAddr;
    Uint16 regOffset;

    //
    //Disable pin locks
    //
    EALLOW;
    GpioCtrlRegs.GPALOCK.all = 0x00000000;
    GpioCtrlRegs.GPBLOCK.all = 0x00000000;
    GpioCtrlRegs.GPCLOCK.all = 0x00000000;
    GpioCtrlRegs.GPDLOCK.all = 0x00000000;
    GpioCtrlRegs.GPELOCK.all = 0x00000000;
    GpioCtrlRegs.GPFLOCK.all = 0x00000000;

    //
    //Fill all registers with zeros. Writing to each register separately
    //for six GPIO modules would make this function *very* long. Fortunately,
    //we'd be writing them all with zeros anyway, so this saves a lot of space.
    //
    gpioBaseAddr = (Uint32 *)&GpioCtrlRegs;
    for (regOffset = 0; regOffset < sizeof(GpioCtrlRegs)/2; regOffset++)
    {
        //
        //Hack to avoid enabling pull-ups on all pins. GPyPUD is offset
        //0x0C in each register group of 0x40 words. Since this is a
        //32-bit pointer, the addresses must be divided by 2.
        //
        if (regOffset % (0x40/2) != (0x0C/2))
        {
            gpioBaseAddr[regOffset] = 0x00000000;
        }
    }

    gpioBaseAddr = (Uint32 *)&GpioDataRegs;
    for (regOffset = 0; regOffset < sizeof(GpioDataRegs)/2; regOffset++)
    {
        gpioBaseAddr[regOffset] = 0x00000000;
    }

    // Pins for DAC         ////////////////////////////////
    GpioCtrlRegs.GPBGMUX2.bit.GPIO54 = 3;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO55 = 0;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO56 = 3;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO57 = 3;

    GpioCtrlRegs.GPBMUX2.bit.GPIO54 = 3;  // GPIO54 = DAC_SDI_SPISIMOA
    GpioCtrlRegs.GPBMUX2.bit.GPIO55 = 0;  // GPIO55 = DAC_nLD_GPIO
    GpioCtrlRegs.GPBMUX2.bit.GPIO56 = 3;  // GPIO56 = DAC_CLK_SPICLKA
    GpioCtrlRegs.GPBMUX2.bit.GPIO57 = 3;  // GPIO57 = DAC_nCS_SPISTEA

    GpioCtrlRegs.GPBDIR.bit.GPIO55 = 1;  // GPIO55 = output

    //SPI
    GpioCtrlRegs.GPBGMUX2.bit.GPIO58 = 1;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO59 = 1;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO60 = 1;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO61 = 1;

    GpioCtrlRegs.GPBMUX2.bit.GPIO58 = 2;  // GPIO58 = DAC_CLK_SPICLKB
    GpioCtrlRegs.GPBMUX2.bit.GPIO59 = 2;  // GPIO59 = DAC_nCS_SPISTEB
    GpioCtrlRegs.GPBMUX2.bit.GPIO60 = 2;  // GPIO60 = DAC_SDI_SPISIMOB
    GpioCtrlRegs.GPBMUX2.bit.GPIO61 = 3;  // GPIO61 = DAC_nLD_SPISOMIB

/*
    GpioCtrlRegs.GPAGMUX2.bit.GPIO16 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO17 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO18 = 0;
    GpioCtrlRegs.GPAGMUX2.bit.GPIO19 = 0;

    GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 1;  // GPIO16 = DAC_SDI_SPISIMOA
    GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 0;  // GPIO17 = DAC_nLD_GPIO
    GpioCtrlRegs.GPAMUX2.bit.GPIO18 = 1;  // GPIO18 = DAC_CLK_SPICLKA
    GpioCtrlRegs.GPAMUX2.bit.GPIO19 = 1;  // GPIO19 = DAC_nCS_SPISTEA

    GpioCtrlRegs.GPADIR.bit.GPIO17 = 1;  // GPIO17 = output


    // Pins for LED[3..0]   ////////////////////////////////
    GpioCtrlRegs.GPBGMUX2.bit.GPIO48 = 0;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO49 = 0;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO50 = 0;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO51 = 0;

    GpioCtrlRegs.GPBMUX2.bit.GPIO48 = 0;  // GPIO48 = LED0_GPIO
    GpioCtrlRegs.GPBMUX2.bit.GPIO49 = 0;  // GPIO49 = LED1_GPIO
    GpioCtrlRegs.GPBMUX2.bit.GPIO50 = 0;  // GPIO50 = LED2_GPIO
    GpioCtrlRegs.GPBMUX2.bit.GPIO51 = 0;  // GPIO51 = LED3_GPIO

    //GpioCtrlRegs.GPBDIR.bit.GPIO48 = 1;  // GPIO48 = output
    //GpioCtrlRegs.GPBDIR.bit.GPIO49 = 1;  // GPIO49 = output
    //GpioCtrlRegs.GPBDIR.bit.GPIO50 = 1;  // GPIO50 = output
    GpioCtrlRegs.GPBDIR.bit.GPIO51 = 1;  // GPIO51 = output
*/

    // GPIO Fault
    GpioCtrlRegs.GPFGMUX1.bit.GPIO167 = 0;
    GpioCtrlRegs.GPFGMUX1.bit.GPIO163 = 0;
    GpioCtrlRegs.GPEGMUX2.bit.GPIO159 = 0;

    GpioCtrlRegs.GPFMUX1.bit.GPIO167 = 0;  // GPIO167 = INV1_nFault
    GpioCtrlRegs.GPFMUX1.bit.GPIO163 = 0;  // GPIO163 = INV2_nFault
    GpioCtrlRegs.GPEMUX2.bit.GPIO159 = 0;  // GPIO159 = INV3_nFault


    GpioCtrlRegs.GPFDIR.bit.GPIO167 = 0;  // GPIO167 = Input
    GpioCtrlRegs.GPFDIR.bit.GPIO163 = 1;  // GPIO163 = Input
    GpioCtrlRegs.GPEDIR.bit.GPIO159 = 0;  // GPIO159 = Input


    //EQEP
    GpioCtrlRegs.GPADIR.bit.GPIO10 = 0;  // GPIO10 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO11 = 0;  // GPIO11 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO13 = 0;  // GPIO13 = Input

    GpioCtrlRegs.GPAQSEL1.bit.GPIO10 = 0;   // Sync GPIO10 to SYSCLK  (EQEP1A)
    GpioCtrlRegs.GPAQSEL1.bit.GPIO11 = 0;   // Sync GPIO11 to SYSCLK  (EQEP1B)
    GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 0;   // Sync GPIO13 to SYSCLK  (EQEP1I)

    GpioCtrlRegs.GPAGMUX1.bit.GPIO10 = 1;   // Configure GPIO10 as EQEP1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;    // Configure GPIO10 as EQEP1A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO11 = 1;   // Configure GPIO11 as EQEP1B
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;    // Configure GPIO11 as EQEP1B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO13 = 1;   // Configure GPIO13 as EQEP1I
    GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;    // Configure GPIO13 as EQEP1I


    GpioCtrlRegs.GPADIR.bit.GPIO24 = 0;  // GPIO24 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO25 = 0;  // GPIO25 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO26 = 0;  // GPIO26 = Input

    GpioCtrlRegs.GPAQSEL2.bit.GPIO24 = 0;   // Sync GPIO10 to SYSCLK  (EQEP2A)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 0;   // Sync GPIO11 to SYSCLK  (EQEP2B)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 0;   // Sync GPIO13 to SYSCLK  (EQEP2I)

    GpioCtrlRegs.GPAGMUX2.bit.GPIO24 = 1;   // Configure GPIO24 as EQEP2A
    GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 1;    // Configure GPIO24 as EQEP2A
    GpioCtrlRegs.GPAGMUX2.bit.GPIO25 = 1;   // Configure GPIO25 as EQEP2B
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 1;    // Configure GPIO25 as EQEP2B
    GpioCtrlRegs.GPAGMUX2.bit.GPIO26 = 1;   // Configure GPIO26 as EQEP2I
    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 1;    // Configure GPIO26 as EQEP2I


    GpioCtrlRegs.GPADIR.bit.GPIO6 = 0;  // GPIO6 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO7 = 0;  // GPIO7 = Input
    GpioCtrlRegs.GPADIR.bit.GPIO9 = 0;  // GPIO9 = Input

    GpioCtrlRegs.GPAQSEL1.bit.GPIO6 = 0;   // Sync GPIO6 to SYSCLK  (EQEP3A)
    GpioCtrlRegs.GPAQSEL1.bit.GPIO7 = 0;   // Sync GPIO7 to SYSCLK  (EQEP3B)
    GpioCtrlRegs.GPAQSEL1.bit.GPIO9 = 0;   // Sync GPIO9 to SYSCLK  (EQEP3I)

    GpioCtrlRegs.GPAGMUX1.bit.GPIO6 = 1;   // Configure GPIO6 as EQEP3A
    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1;    // Configure GPIO6 as EQEP3A
    GpioCtrlRegs.GPAGMUX1.bit.GPIO7 = 1;   // Configure GPIO7 as EQEP3B
    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1;    // Configure GPIO7 as EQEP3B
    GpioCtrlRegs.GPAGMUX1.bit.GPIO9 = 1;   // Configure GPIO9 as EQEP3I
    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 1;    // Configure GPIO9 as EQEP3I


    //CAN
    GpioCtrlRegs.GPCGMUX1.bit.GPIO70 = 1;    // Configure GRIO70 as CANRXA
    GpioCtrlRegs.GPCMUX1.bit.GPIO70 = 1;     // Configure GRIO70 as CANRXA    
    GpioCtrlRegs.GPCGMUX1.bit.GPIO71 = 1;    // Configure GRIO71 as CANTXA
    GpioCtrlRegs.GPCMUX1.bit.GPIO71 = 1;     // Configure GRIO71 as CANTXA

    GpioCtrlRegs.GPCQSEL1.bit.GPIO70 = 3;   // Async GPIO70 to SYSCLK  (CANRXA)
    GpioCtrlRegs.GPCQSEL1.bit.GPIO71 = 3;   // Async GPIO71 to SYSCLK  (CANTXA)

	GpioCtrlRegs.GPCPUD.bit.GPIO70 = 0;	    // Enable pull-up for GPIO70 (CANRXA)
	GpioCtrlRegs.GPCPUD.bit.GPIO71 = 0;	    // Enable pull-up for GPIO71 (CANTXA)

    GpioCtrlRegs.GPCDIR.bit.GPIO70 = 0;  // GPIO70 = Input
    GpioCtrlRegs.GPCDIR.bit.GPIO71 = 1;  // GPIO71 = Output
    
/*
    GpioCtrlRegs.GPAPUD.bit.GPIO10 = 0;  // Enable pull-up on GPIO10(EQEP1A)
    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0;  // Enable pull-up on GPIO11(EQEP1B)
    GpioCtrlRegs.GPAPUD.bit.GPIO13 = 0;  // Enable pull-up on GPIO13(EQEP1I)

    GpioCtrlRegs.GPAPUD.bit.GPIO24 = 0;  // Enable pull-up on GPIO24(EQEP2A)
    GpioCtrlRegs.GPAPUD.bit.GPIO25 = 0;  // Enable pull-up on GPIO25(EQEP2B)
    //GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;  // Enable pull-up on GPIO26(EQEP2I)

    GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;  // Enable pull-up on GPIO28(EQEP3A)
    GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;  // Enable pull-up on GPIO29(EQEP3B)
    //GpioCtrlRegs.GPAPUD.bit.GPIO31 = 0;  // Enable pull-up on GPIO31(EQEP3I)


    GpioCtrlRegs.GPAQSEL1.bit.GPIO10 = 0;  // Sync to SYSCLKOUT GPIO10 (EQEP1A)
    GpioCtrlRegs.GPAQSEL1.bit.GPIO11 = 0;  // Sync to SYSCLKOUT GPIO11 (EQEP1B)
   // GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 0;  // Sync to SYSCLKOUT GPIO13 (EQEP1I)

    GpioCtrlRegs.GPAQSEL2.bit.GPIO24 = 0;  // Sync to SYSCLKOUT GPIO24 (EQEP2A)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO25 = 0;  // Sync to SYSCLKOUT GPIO25 (EQEP2B)
   // GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 0;  // Sync to SYSCLKOUT GPIO26 (EQEP2I)

    GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 0;  // Sync to SYSCLKOUT GPIO28 (EQEP3A)
    GpioCtrlRegs.GPAQSEL2.bit.GPIO29 = 0;  // Sync to SYSCLKOUT GPIO29 (EQEP3B)
   // GpioCtrlRegs.GPAQSEL2.bit.GPIO31 = 0;  // Sync to SYSCLKOUT GPIO31 (EQEP3I)


    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;  // GPIO10 = EQEP1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;  // GPIO11 = EQEP1B
   // GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;  // GPIO13 = EQEP1I

    GpioCtrlRegs.GPAMUX2.bit.GPIO24 = 1;  // GPIO24 = EQEP2A
    GpioCtrlRegs.GPAMUX2.bit.GPIO25 = 1;  // GPIO25 = EQEP2B
   // GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 1;  // GPIO26 = EQEP2I

    GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;  // GPIO28 = EQEP3A
    GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;  // GPIO29 = EQEP3B
   // GpioCtrlRegs.GPAMUX2.bit.GPIO31 = 1;  // GPIO31 = EQEP3I
*/

    GpioDataRegs.GPBSET.all = (Uint32)(0x000f0000);


    EDIS;
}


//
// GPIO_SetupPinMux - Set the peripheral muxing for the specified pin. The
//                    appropriate parameters can be found in the GPIO Muxed
//                    Pins table in the datasheet. Use the GPIO index row
//                   (0 to 15) to select a muxing option for the GPIO.
//
void GPIO_SetupPinMux(Uint16 pin, Uint16 cpu, Uint16 peripheral)
{
    volatile Uint32 *gpioBaseAddr;
    volatile Uint32 *mux, *gmux, *csel;
    Uint16 pin32, pin16, pin8;

    pin32 = pin % 32;
    pin16 = pin % 16;
    pin8 = pin % 8;
    gpioBaseAddr = (Uint32 *)&GpioCtrlRegs + (pin/32)*GPY_CTRL_OFFSET;

    //
    //Sanity check for peripheral values
    //
    if (peripheral > 0xF)
    {
        return;
    }

    //
    //Create pointers to the appropriate registers. This is a workaround
    //for the way GPIO registers are defined. The standard definition
    //in the header file makes it very easy to do named accesses of one
    //register or bit, but hard to do arbitrary numerical accesses. It's
    //easier to have an array of GPIO modules with identical registers,
    //including arrays for multi-register groups like GPyCSEL1-4. But
    //the header file doesn't define anything we can turn into an array,
    //so manual pointer arithmetic is used instead.
    //
    mux = gpioBaseAddr + GPYMUX + pin32/16;
    gmux = gpioBaseAddr + GPYGMUX + pin32/16;
    csel = gpioBaseAddr + GPYCSEL + pin32/8;

    //
    //Now for the actual function
    //
    EALLOW;

    //
    //To change the muxing, set the peripheral mux to 0/GPIO first to avoid
    //glitches, then change the group mux, then set the peripheral mux to
    //its target value. Finally, set the CPU select. This procedure is
    //described in the TRM. Unfortunately, since we don't know the pin in
    //advance we can't hardcode a bitfield reference, so there's some tricky
    //bit twiddling here.
    //
    *mux &= ~(0x3UL << (2*pin16));
    *gmux &= ~(0x3UL << (2*pin16));
    *gmux |= (Uint32)((peripheral >> 2) & 0x3UL) << (2*pin16);
    *mux |= (Uint32)(peripheral & 0x3UL) << (2*pin16);

    *csel &= ~(0x3L << (4*pin8));
    *csel |= (Uint32)(cpu & 0x3L) << (4*pin8);

    //
    //WARNING: This code does not touch the analog mode select registers,
    //which are needed to give the USB module control of its IOs.
    //

    EDIS;
}

//
// GPIO_SetupPinOptions - Setup up the GPIO input/output options for the
//                        specified pin.
//                        The flags are a 16-bit mask produced by ORing
//                        together options.
//                        For input pins, the valid flags are:
//                        GPIO_PULLUP  Enable pull-up
//                        GPIO_INVERT  Enable input polarity inversion
//                        GPIO_SYNC    Synchronize the input latch to PLLSYSCLK
//                                     (default-you don't need to specify this)
//                        GPIO_QUAL3   Use 3-sample qualification
//                        GPIO_QUAL6   Use 6-sample qualification
//                        GPIO_ASYNC   Do not use synchronization or
//                                     qualification
//                        (Note: only one of SYNC, QUAL3, QUAL6, or ASYNC is
//                         allowed)
//
//                        For output pins, the valid flags are:
//                        GPIO_OPENDRAIN   Output in open drain mode
//                        GPIO_PULLUP      If open drain enabled, also enable
//                                         the pull-up and the input
//                                         qualification flags
//                                        (SYNC/QUAL3/QUAL6/SYNC) listed above.
//
//                        With no flags, the default input state is synchronous
//                        with no pull-up or polarity inversion. The default
//                        output state is the standard digital output.
//
void GPIO_SetupPinOptions(Uint16 pin, Uint16 output, Uint16 flags)
{
    volatile Uint32 *gpioBaseAddr;
    volatile Uint32 *dir, *pud, *inv, *odr, *qsel;
    Uint32 pin32, pin16, pinMask, qual;

    pin32 = pin % 32;
    pin16 = pin % 16;
    pinMask = 1UL << pin32;
    gpioBaseAddr = (Uint32 *)&GpioCtrlRegs + (pin/32)*GPY_CTRL_OFFSET;

    //
    //Create pointers to the appropriate registers. This is a workaround
    //for the way GPIO registers are defined. The standard definition
    //in the header file makes it very easy to do named accesses of one
    //register or bit, but hard to do arbitrary numerical accesses. It's
    //easier to have an array of GPIO modules with identical registers,
    //including arrays for multi-register groups like GPyQSEL1-2. But
    //the header file doesn't define anything we can turn into an array,
    //so manual pointer arithmetic is used instead.
    //
    dir = gpioBaseAddr + GPYDIR;
    pud = gpioBaseAddr + GPYPUD;
    inv = gpioBaseAddr + GPYINV;
    odr = gpioBaseAddr + GPYODR;
    qsel = gpioBaseAddr + GPYQSEL + pin32/16;

    EALLOW;

    //
    //Set the data direction
    //
    *dir &= ~pinMask;
    if (output == 1)
    {
        //
        //Output, with optional open drain mode and pull-up
        //
        *dir |= pinMask;

        //
        //Enable open drain if necessary
        //
        if (flags & GPIO_OPENDRAIN)
        {
            *odr |= pinMask;
        }
        else
        {
            *odr &= ~pinMask;
        }

        //
        //Enable pull-up if necessary. Open drain mode must be active.
        //
        if (flags & (GPIO_OPENDRAIN | GPIO_PULLUP))
        {
            *pud &= ~pinMask;
        }
        else
        {
            *pud |= pinMask;
        }
    }
    else
    {
        //
        //Input, with optional pull-up, qualification, and polarity inversion
        //
        *dir &= ~pinMask;

        //
        //Enable pull-up if necessary
        //
        if (flags & GPIO_PULLUP)
        {
            *pud &= ~pinMask;
        }
        else
        {
            *pud |= pinMask;
        }

        //
        //Invert polarity if necessary
        //
        if (flags & GPIO_INVERT)
        {
            *inv |= pinMask;
        }
        else
        {
            *inv &= ~pinMask;
        }
    }

    //
    //Extract the qualification parameter and load it into the register.
    //This is also needed for open drain outputs, so we might as well do it
    //all the time.
    //
    qual = (flags & GPIO_ASYNC) / GPIO_QUAL3;
    *qsel &= ~(0x3L << (2 * pin16));
    if (qual != 0x0)
    {
        *qsel |= qual << (2 * pin16);
    }

    EDIS;
}

//
// GPIO_SetupLock - Enable or disable the GPIO register bit lock for the
//                  specified pin.
//                  The valid flags are:
//                  GPIO_UNLOCK   Unlock the pin setup register bits for the
//                                specified pin
//                  GPIO_LOCK     Lock the pin setup register bits for the
//                                specified pin
//
void GPIO_SetupLock(Uint16 pin, Uint16 flags)
{
    volatile Uint32 *gpioBaseAddr;
    volatile Uint32 *lock;
    Uint32 pin32, pinMask;

    pin32 = pin % 32;
    pinMask = 1UL << pin32;
    gpioBaseAddr = (Uint32 *)&GpioCtrlRegs + (pin/32)*GPY_CTRL_OFFSET;

    //
    //Create pointers to the appropriate registers. This is a workaround
    //for the way GPIO registers are defined. The standard definition
    //in the header file makes it very easy to do named accesses of one
    //register or bit, but hard to do arbitrary numerical accesses. It's
    //easier to have an array of GPIO modules with identical registers,
    //including arrays for multi-register groups like GPyQSEL1-2. But
    //the header file doesn't define anything we can turn into an array,
    //so manual pointer arithmetic is used instead.
    //
    lock = gpioBaseAddr + GPYLOCK;

    EALLOW;
    if(flags)
    {
        //
        //Lock the pin
        //
        *lock |= pinMask;
    }
    else
    {
        //
        //Unlock the pin
        //
        *lock &= ~pinMask;
    }
    EDIS;
}

//
// GPIO_SetupXINT1Gpio - External interrupt setup
//
void GPIO_SetupXINT1Gpio(Uint16 pin)
{
    EALLOW;
    InputXbarRegs.INPUT4SELECT = pin;       //Set XINT1 source to GPIO-pin
    EDIS;
}

//
// GPIO_SetupXINT2Gpio - External interrupt setup
//
void GPIO_SetupXINT2Gpio(Uint16 pin)
{
    EALLOW;
    InputXbarRegs.INPUT5SELECT = pin;       //Set XINT2 source to GPIO-pin
    EDIS;
}

//
// GPIO_SetupXINT3Gpio - External interrupt setup
//
void GPIO_SetupXINT3Gpio(Uint16 pin)
{
    EALLOW;
    InputXbarRegs.INPUT6SELECT = pin;       //Set XINT3 source to GPIO-pin
    EDIS;
}

//
// GPIO_SetupXINT4Gpio - External interrupt setup
//
void GPIO_SetupXINT4Gpio(Uint16 pin)
{
    EALLOW;
    InputXbarRegs.INPUT13SELECT = pin;     //Set XINT4 source to GPIO-pin
    EDIS;
}

//
// GPIO_SetupXINT5Gpio - External interrupt setup
//
void GPIO_SetupXINT5Gpio(Uint16 pin)
{
    EALLOW;
    InputXbarRegs.INPUT14SELECT = pin;     //Set XINT5 source to GPIO-pin
    EDIS;
}

//
// GPIO_EnableUnbondedIOPullupsFor176Pin - Enable pullups for the unbonded
//                                         GPIOs on the 176PTP package:
//                                         GPIOs     Grp Bits
//                                         95-132    C   31
//                                                   D   31:0
//                                                   E   4:0
//                                         134-168   E   31:6
//                                                   F   8:0
//
void GPIO_EnableUnbondedIOPullupsFor176Pin()
{
    EALLOW;
    GpioCtrlRegs.GPCPUD.all = ~0x80000000;  //GPIO 95
    GpioCtrlRegs.GPDPUD.all = ~0xFFFFFFF7;  //GPIOs 96-127
    GpioCtrlRegs.GPEPUD.all = ~0xFFFFFFDF;  //GPIOs 128-159 except for 133
    GpioCtrlRegs.GPFPUD.all = ~0x000001FF;  //GPIOs 160-168
    EDIS;
}

//
// GPIO_EnableUnbondedIOPullupsFor100Pin - Enable pullups for the unbonded
//                                         GPIOs on the 100PZ package:
//                                         GPIOs     Grp Bits
//                                         0-1       A   1:0
//                                         5-9       A   9:5
//                                         22-40     A   31:22
//                                                   B   8:0
//                                         44-57     B   25:12
//                                         67-68     C   4:3
//                                         74-77     C   13:10
//                                         79-83     C   19:15
//                                         93-168    C   31:29
//                                                   D   31:0
//                                                   E   31:0
//                                                   F   8:0
//
void GPIO_EnableUnbondedIOPullupsFor100Pin()
{
    EALLOW;
    GpioCtrlRegs.GPAPUD.all = ~0xFFC003E3;  //GPIOs 0-1, 5-9, 22-31
    GpioCtrlRegs.GPBPUD.all = ~0x03FFF1FF;  //GPIOs 32-40, 44-57
    GpioCtrlRegs.GPCPUD.all = ~0xE10FBC18;  //GPIOs 67-68, 74-77, 79-83, 93-95
    GpioCtrlRegs.GPDPUD.all = ~0xFFFFFFF7;  //GPIOs 96-127
    GpioCtrlRegs.GPEPUD.all = ~0xFFFFFFFF;  //GPIOs 128-159
    GpioCtrlRegs.GPFPUD.all = ~0x000001FF;  //GPIOs 160-168
    EDIS;
}

//
// GPIO_EnableUnbondedIOPullups - Enable IO pullups for specific package
//
void GPIO_EnableUnbondedIOPullups()
{
    unsigned char pin_count = ((DevCfgRegs.PARTIDL.all & 0x00000700) >> 8) ;

    //
    // 5 = 100 pin
    // 6 = 176 pin
    // 7 = 337 pin
    //
    if(pin_count == 5)
    {
        GPIO_EnableUnbondedIOPullupsFor100Pin();
    }
    else if (pin_count == 6)
    {
        GPIO_EnableUnbondedIOPullupsFor176Pin();
    }
    else
    {
        //
        //do nothing - this is 337 pin package
        //
    }
}

//
// GPIO_ReadPin - Read the GPyDAT register bit for the specified pin.
//                Note that this returns the actual state of the pin,
//                not the state of the output latch.
//
Uint16 GPIO_ReadPin(Uint16 pin)
{
    volatile Uint32 *gpioDataReg;
    Uint16 pinVal;

    gpioDataReg = (volatile Uint32 *)&GpioDataRegs + (pin/32)*GPY_DATA_OFFSET;
    pinVal = (gpioDataReg[GPYDAT] >> (pin % 32)) & 0x1;

    return pinVal;
}

//
// GPIO_WritePin - Set the GPyDAT register bit for the specified pin.
//
void GPIO_WritePin(Uint16 pin, Uint16 outVal)
{
    volatile Uint32 *gpioDataReg;
    Uint32 pinMask;

    gpioDataReg = (volatile Uint32 *)&GpioDataRegs + (pin/32)*GPY_DATA_OFFSET;
    pinMask = 1UL << (pin % 32);

    if (outVal == 0)
    {
        gpioDataReg[GPYCLEAR] = pinMask;
    }
    else
    {
        gpioDataReg[GPYSET] = pinMask;
    }
}

//
// End of file
//
